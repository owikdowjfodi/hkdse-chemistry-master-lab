// Coordinates belong to the measurement stream; rendering never interpolates observations.
const isPoint = p => p != null && Number.isFinite(p.x) && Number.isFinite(p.y);
const validPoints = values => Array.isArray(values) ? values.filter(isPoint) : [];

export function statistics(points) {
  let n = 0, meanX = 0, meanY = 0, sumXX = 0, sumXY = 0, sumYY = 0;
  for (const { x, y } of validPoints(points)) {
    n += 1;
    const dx = x - meanX, dy = y - meanY;
    meanX += dx / n;
    meanY += dy / n;
    sumXX += dx * (x - meanX);
    sumXY += dx * (y - meanY);
    sumYY += dy * (y - meanY);
  }
  const slope = sumXX > 0 ? sumXY / sumXX : null;
  return {
    n,
    mean: n ? meanY : null,
    sd: n > 1 ? Math.sqrt(Math.max(0, sumYY) / (n - 1)) : null,
    slope,
    intercept: slope === null ? null : meanY - slope * meanX
  };
}

function makeScale(min, max, intervals, anchorZero) {
  if (!Number.isFinite(min) || !Number.isFinite(max)) return { lo: 0, hi: 1, ticks: [0, 0.5, 1] };
  if (anchorZero) min = Math.min(min, 0);
  if (min === max) {
    const delta = Math.max(1, Math.abs(max) * 0.05);
    if (!anchorZero || min < 0) min -= delta;
    max += delta;
  }
  const raw = (max - min) / intervals;
  const magnitude = 10 ** Math.floor(Math.log10(raw));
  const step = ([1, 2, 2.5, 5, 10].find(v => v * magnitude >= raw) || 10) * magnitude;
  const lo = Math.floor(min / step) * step;
  const hi = Math.ceil(max / step) * step;
  return {
    lo, hi,
    ticks: Array.from({length: Math.round((hi - lo) / step) + 1}, (_, i) => lo + i * step)
  };
}

function tickLabel(value) {
  if (value === 0) return '0';
  if (Math.abs(value) >= 10000 || Math.abs(value) < 0.001) return value.toExponential(0).replace('+', '');
  return String(Number(value.toPrecision(5)));
}

function extrema(series, key) {
  let min = Infinity, max = -Infinity;
  for (const points of series) {
    for (const p of points) {
      min = Math.min(min, p[key]);
      max = Math.max(max, p[key]);
    }
  }
  return [min, max];
}

export function drawPlot(canvas, { points = [], compare = [], xlabel = '', ylabel = '', key = '', en = false } = {}) {
  const data = validPoints(points), reference = validPoints(compare);
  const last = data.at(-1);
  const caption = en ? 'Latest measurement' : '最新量度';
  const accessible = [ylabel, xlabel, last && (caption + ' (' + tickLabel(last.x) + ', ' + tickLabel(last.y) + ')')].filter(Boolean).join(' · ');
  canvas.setAttribute('aria-label', accessible || (en ? 'Measurement chart' : '實驗量度圖'));
  const rect = canvas.getBoundingClientRect();
  if (rect.width < 70 || rect.height < 55) return;
  const w = Math.round(rect.width), h = Math.round(rect.height);
  const dpr = Math.min(3, Math.max(1, globalThis.devicePixelRatio || 1));
  const pixelsW = Math.round(w * dpr), pixelsH = Math.round(h * dpr);
  if (canvas.width !== pixelsW) canvas.width = pixelsW;
  if (canvas.height !== pixelsH) canvas.height = pixelsH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);
  const xBounds = extrema([data, reference], 'x');
  const yBounds = extrema([data, reference], 'y');
  const titration = key === 'titration';
  const xScale = titration && xBounds[0] >= 0 && xBounds[1] <= 50
    ? { lo: 0, hi: 50, ticks: w < 230 ? [0, 25, 50] : [0, 10, 20, 30, 40, 50] }
    : makeScale(...xBounds, w < 230 ? 3 : 5, true);
  const yScale = titration && yBounds[0] >= 0 && yBounds[1] <= 14
    ? { lo: 0, hi: 14, ticks: h < 150 ? [0, 7, 14] : [0, 3.5, 7, 10.5, 14] }
    : makeScale(...yBounds, h < 145 ? 3 : 4, key !== 'heat');
  const numberFont = '10px ui-monospace, SFMono-Regular, Consolas, monospace';
  const labelFont = '11px system-ui, sans-serif';
  ctx.font = numberFont;
  const labelWidth = Math.max(...yScale.ticks.map(t => ctx.measureText(tickLabel(t)).width));
  const left = Math.ceil(labelWidth) + 8, right = w - 12, top = 19, bottom = h - 32;
  const X = x => left + (x - xScale.lo) / (xScale.hi - xScale.lo) * (right - left);
  const Y = y => bottom - (y - yScale.lo) / (yScale.hi - yScale.lo) * (bottom - top);

  ctx.fillStyle = '#f6f9f4';
  ctx.fillRect(left, top, right - left, bottom - top);
  ctx.font = numberFont;
  ctx.lineWidth = 1;
  ctx.textBaseline = 'middle';
  function grid(x1, y1, x2, y2) {
    ctx.beginPath();
    ctx.moveTo(Math.round(x1) + 0.5, Math.round(y1) + 0.5);
    ctx.lineTo(Math.round(x2) + 0.5, Math.round(y2) + 0.5);
    ctx.stroke();
  }
  for (const t of yScale.ticks) {
    const y = Y(t);
    ctx.strokeStyle = '#ccdad1'; grid(left, y, right, y);
    ctx.textAlign = 'right'; ctx.fillStyle = '#4d655c';
    ctx.fillText(tickLabel(t), left - 5, y);
  }
  for (const t of xScale.ticks) {
    const x = X(t);
    ctx.strokeStyle = '#e0e8e1'; grid(x, top, x, bottom);
    ctx.textAlign = 'center'; ctx.fillStyle = '#4d655c';
    ctx.fillText(tickLabel(t), x, bottom + 10);
  }
  ctx.fillStyle = '#3c5b50';
  ctx.font = labelFont;
  ctx.textAlign = 'left'; ctx.fillText(ylabel, left, 7, (right - left) * (reference.length ? .52 : 1));
  ctx.textAlign = 'right'; ctx.fillText(xlabel, right, h - 5, right - left);

  function trace(values, colour, dashed) {
    if (!values.length) return;
    ctx.beginPath();
    values.forEach((point, i) => {
      const x = X(point.x), y = Y(point.y);
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.lineWidth = dashed ? 1.7 : 2.1;
    ctx.lineJoin = 'round';
    ctx.setLineDash(dashed ? [4, 4] : []);
    ctx.strokeStyle = colour;
    ctx.stroke();
    ctx.setLineDash([]);
    // Preserve the individual measurement marks while they are distinguishable.
    if (values.length <= Math.max(10, (right - left) / 7)) {
      ctx.fillStyle = colour;
      for (const p of values) {
        ctx.beginPath();
        ctx.arc(X(p.x), Y(p.y), 2, 0, 2 * Math.PI);
        ctx.fill();
      }
    }
  }
  if (reference.length) {
    trace(reference, '#ae6b39', true);
    ctx.textAlign = 'right'; ctx.fillStyle = '#94552b';
    ctx.fillText(en ? '– –  Prior trial' : '– –  對照試驗', right, 7, (right - left) * .45);
  }
  trace(data, '#167b65', false);
  if (last) {
    ctx.beginPath();
    ctx.arc(X(last.x), Y(last.y), 4, 0, 2 * Math.PI);
    ctx.fillStyle = '#0c725d'; ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5; ctx.stroke();
  } else if (!reference.length) {
    ctx.textAlign = 'center'; ctx.fillStyle = '#51685e';
    ctx.fillText(en ? 'Awaiting a measurement' : '等待量度數據', (right + left) / 2, (top + bottom) / 2, right - left);
  }
}
