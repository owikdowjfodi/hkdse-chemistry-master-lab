// Illustrative, fixed case studies. Frame indices are narrative, not physical time.
const cases = [
  {
    name:['局部起火','Localised fire'],
    stages:[
      ['操作前','Before work','工作區尚未完成安全檢查。','The pre-start check is incomplete.'],
      ['首個錯誤','First error','操作人員忽略火警提示，繼續操作。','The operator continues after a fire warning.'],
      ['可見後果','Visible consequence','案例畫面顯示工作枱上的局部火焰。','The case shows a localised flame on the work surface.'],
      ['安全回應','Safety response','學生退開、提醒附近人士並通知教師，按學校程序行動。','Students step away, alert others and notify the teacher, following the school procedure.']
    ],
    prevention:['動手前辨認警報、出口及教師位置，出現警號便停止操作。','Locate the alarm, exit and teacher before work. Stop if a warning appears.']
  },
  {
    name:['壓力警告與玻璃破裂','Pressure warning and glass failure'],
    stages:[
      ['操作前','Before work','儀器仍完整，工作區由屏障分隔。','The apparatus is intact behind a screen.'],
      ['首個錯誤','First error','裝置已出現壓力異常警號，操作卻未中止。','An abnormal-pressure warning appears and the operation continues.'],
      ['可見後果','Visible consequence','在這個固定案例中，器皿出現裂紋並局部破裂。','In this fixed case the vessel develops a crack and a section fails.'],
      ['安全回應','Safety response','保持距離，提醒附近人士並通知教師；由受訓人員處理裝置。','Keep clear, alert others and notify the teacher. Trained staff manage the apparatus.']
    ],
    prevention:['操作前由教師核對裝置；遇到異常指示便立即停手並報告。','Have the setup checked before work. Stop and report abnormal instrument indications.']
  },
  {
    name:['玻璃破損與外洩','Breakage and spill'],
    stages:[
      ['操作前','Before work','玻璃器皿在工作枱上，枱邊附近有移動空間。','A glass vessel stands near the working edge of the bench.'],
      ['首個錯誤','First error','移動其他器材時碰到未穩放的器皿。','Moving equipment knocks an unsecured vessel.'],
      ['可見後果','Visible consequence','器皿傾倒破損，液體外洩，附近留下玻璃碎片。','The vessel tips, breaks and spills liquid. Glass fragments remain nearby.'],
      ['安全回應','Safety response','退開並通知教師，避免他人踏入外洩範圍或接觸碎玻璃。','Step away and alert the teacher. Keep people clear of the spill and broken glass.']
    ],
    prevention:['將玻璃器皿穩放於工作枱中央，移動器材前先清理路線。','Place glassware securely near the centre of the bench and clear its route before moving it.']
  }
];
const source='https://www.edb.gov.hk/attachment/en/edu-system/primary-secondary/applicable-to-secondary/moi/support-and-resources-for-moi-policy/lsplmfs-sch/d-sch/ow/tifeltiem-sch/content.pdf';
function diagram(caseIndex,frame){
 const glass='<path d="M154 78h60m-54 1v61q0 7 7 7h35q7 0 7-7V79" fill="#deefeb" stroke="#67948c" stroke-width="3"/><path d="M161 118q10-3 20 0t27 0v21q0 6-6 6h-35q-6 0-6-6z" fill="#8ebeb1"/><path d="M198 89h9m-6 9h6m-9 10h9" stroke="#67948c" stroke-width="2"/>';
 const alarm='<g transform="translate(240 38)"><path d="M0 29 16 0l17 29z" fill="#f3ca74" stroke="#826436" stroke-width="2"/><path d="M16 10v8m0 3v2" stroke="#58462b" stroke-width="3" stroke-linecap="round"/></g>';
 const flame='<g><path d="M252 146c-13-18 6-24 7-39 8 8 6 15 8 16 5-5 7-12 6-16 13 21 14 32 7 39z" fill="#ef9a52" stroke="#ab6737" stroke-width="2"/><path d="M260 145c-2-7 5-13 7-17 4 6 6 9 5 17" fill="#ffe2a2"/></g>';
 const cracks='<path d="m194 81-7 17 6 10-10 11 3 17m7-28 13 6" stroke="#527570" fill="none" stroke-width="3"/><path d="m217 145 8-9 2 8zM233 146l5-4 4 4z" fill="#adcfc6" stroke="#719990"/>';
 const spill='<ellipse cx="217" cy="146" rx="47" ry="5" fill="#82b4a7"/><ellipse cx="263" cy="146" rx="7" ry="2" fill="#82b4a7"/>';
 const tape='<g stroke="#bd9147" stroke-width="5"><path d="M95 155l220-16"/></g><path d="M95 155l220-16" stroke="#f3d997" stroke-width="5" stroke-dasharray="12 10"/>';
 const shield=caseIndex===1?'<path d="M254 62v84m0-85 16-8v91l-16 3" fill="#9bbab13d" stroke="#94afa4" stroke-width="2"/>':'';
 const rotate=caseIndex===2?(frame>=2?-71:frame===1?-16:0):0;
 return '<svg width="100%" viewBox="0 0 400 169" aria-hidden="true" focusable="false"><rect width="400" height="169" rx="8" fill="#e9efe8"/><path d="M0 148h400v21H0z" fill="#d1e0d5"/><path d="M0 148h400" stroke="#8ca99d" stroke-width="2"/>'+shield+
 (caseIndex===2&&frame>=2?spill:'')+'<g transform="rotate('+rotate+' 159 145)">'+glass+(caseIndex!==0&&frame>=2?cracks:'')+'</g>'+
 (frame===1?alarm:'')+(caseIndex===0&&frame>=2?flame:'')+(frame===3?tape:'')+'</svg>';
}
export function mountIncidents(container,{en=false,lowMotion=false}={}){
 const t=(zh,english)=>en?english:zh;
 const root=document.createElement('section');
 root.className='incident-view';
 container.replaceChildren(root);
 let idx=0,frame=0,timer=null,slow=false,disposed=false;
 root.innerHTML='<style>.incident-view{color:#23443d}.incident-view h3{margin:.8rem 0 .25rem}.incident-view p{line-height:1.55}.incident-view .incident-frame{border:1px solid #c9d9cb;border-radius:9px;overflow:hidden;background:#f3f7f0}.incident-view svg{display:block;max-height:180px}.incident-view figcaption{padding:.5rem .8rem;font-size:.84rem;color:#496459}.incident-view figure{margin:.8rem 0}.incident-view .incident-controls,.incident-view .incident-nav{display:flex;flex-wrap:wrap;gap:.45rem;margin:.6rem 0}.incident-view button{min-height:38px}.incident-view [aria-current="step"],.incident-view [aria-pressed="true"]{background:#e2eddb;color:#234939;border-color:#85a58a}.incident-view select{max-width:100%;width:100%}.incident-view .incident-details{border-left:3px solid #85a58a;padding:.15rem .8rem}.incident-view .source{font-size:.86rem;color:#46675d}.incident-view .source a{color:inherit;text-decoration:underline}</style>'+
 '<label></label><select aria-label="'+t('選擇事故案例','Choose case study')+'">'+cases.map((c,i)=>'<option value="'+i+'">'+c.name[Number(!!en)]+'</option>').join('')+'</select>'+
 '<figure class="incident-frame"><div class="drawing"></div><figcaption>'+t('預設教學案例 · C 級示意圖。此處的時間線獨立於你的操作紀錄。','Fixed educational case · Class C schematic. This timeline is separate from your experiment log.')+'</figcaption></figure><div class="incident-nav"></div><div class="incident-details" aria-live="polite" aria-atomic="true"><h3></h3><p></p></div><div class="incident-controls"></div><p class="prevention"></p><p class="source"></p>';
 const sel=root.querySelector('select'),nav=root.querySelector('.incident-nav'),controls=root.querySelector('.incident-controls');
 const label=root.querySelector('label');
 label.textContent=t('事故案例','Case study'); label.append(sel);
 const qs=s=>root.querySelector(s);
 function button(parent,fn){const b=document.createElement('button');b.type='button';b.onclick=fn;parent.append(b);return b;}
 function halt(){if(timer!==null){clearInterval(timer);timer=null;}}
 function animate(){
   if(lowMotion||disposed)return;
   if(timer!==null){halt();render();return;}
   if(frame===3)frame=0;
   timer=setInterval(()=>{frame=Math.min(3,frame+1);if(frame===3)halt();render();},slow?4600:2300);
   render();
 }
 const steps=Array.from({length:4},(_,i)=>button(nav,()=>{halt();frame=i;render();}));
 const play=button(controls,animate),next=button(controls,()=>{halt();frame=Math.min(3,frame+1);render();}),reset=button(controls,()=>{halt();frame=0;render();}),speed=button(controls,()=>{const running=timer!==null;halt();slow=!slow;if(running)animate();else render();});
 play.disabled=speed.disabled=!!lowMotion;
 sel.onchange=()=>{halt();idx=Number(sel.value);frame=0;render();};
 function render(){
  const record=cases[idx], stage=record.stages[frame],lang=Number(!!en);
  qs('.drawing').innerHTML=diagram(idx,frame);
  qs('h3').textContent=stage[lang];qs('.incident-details p').textContent=stage[2+lang];
  steps.forEach((b,i)=>{b.textContent=record.stages[i][lang];if(i===frame)b.setAttribute('aria-current','step');else b.removeAttribute('aria-current');});
  play.textContent=lowMotion?t('低動態：逐格觀看','Reduced motion: step through'):timer===null?t('播放','Play'):t('暫停','Pause');
  next.textContent=t('下一格','Next frame');next.disabled=frame===3;
  reset.textContent=t('返回案例起點','Rewind case');reset.disabled=frame===0&&timer===null;
  speed.textContent=t('半速播放','Half speed');speed.setAttribute('aria-pressed',String(slow));
  qs('.prevention').textContent=t('預防方法　','Prevention · ')+record.prevention[lang];
  qs('.source').innerHTML=t('示意圖只表示先後次序。破裂形態、火焰大小及外洩範圍並非測量或預測值。一般學校安全原則參考','Frames show sequence only. Breakage, flame size and spill extent are illustrative. General school safety guidance:')+' <a target="_blank" rel="noopener noreferrer" href="'+source+'">'+t('香港教育局課堂實驗室安全指引，第 16 頁','Hong Kong EDB classroom laboratory guidance, p. 16')+'</a>'+t('。','.');
 }
 render();return ()=>{disposed=true;halt();root.remove();};
}
