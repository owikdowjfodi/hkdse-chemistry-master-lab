// Offline inventory. Capacities are the chosen virtual vessel sizes in mL,
// not tolerances or manufacturer specifications for a particular product.
const apparatusSource = 'HKDSE Chemistry Master Lab 3D master specification, sections 3 and 6';
const equipmentGroups = {
  '玻璃器材 Glassware': [
    ['beaker','燒杯','Beaker','beaker',250], ['tube','試管','Test tube','tube',20],
    ['boilingTube','沸騰管','Boiling tube','tube',50], ['flask','錐形瓶','Conical flask','flask',250],
    ['volumetricFlask','容量瓶','Volumetric flask'], ['cylinder','量筒','Measuring cylinder','cylinder',100],
    ['burette','滴定管','Burette','burette',50], ['pipette','移液管','Volumetric pipette','pipette',25],
    ['graduatedPipette','刻度移液管','Graduated pipette','pipette',10], ['dropper','滴管','Dropper','dropper',2],
    ['rod','玻璃棒','Glass rod'], ['funnel','過濾漏斗','Filter funnel','funnel'],
    ['separatingFunnel','分液漏斗','Separating funnel'], ['evaporatingDish','蒸發皿','Evaporating dish'],
    ['crucible','坩堝','Crucible'], ['watchGlass','錶面皿','Watch glass'],
    ['roundFlask','圓底燒瓶','Round-bottom flask'], ['flatFlask','平底燒瓶','Flat-bottom flask'],
    ['condenser','冷凝管','Condenser'], ['receivingFlask','接收瓶','Receiving flask','flask',100],
    ['washGas','洗氣瓶','Gas washing bottle'], ['syringe','氣體注射器','Gas syringe','syringe'],
    ['bottle','試劑瓶','Reagent bottle','bottle',100], ['washBottle','洗瓶','Wash bottle'],
    ['desiccator','乾燥器','Desiccator']
  ],
  '加熱與支架 Heating & stands': [
    ['burner','本生燈','Bunsen burner','burner'], ['hotPlate','電熱板','Hot plate','plate'],
    ['mantle','電熱套','Heating mantle'], ['waterBath','水浴','Water bath'], ['oilBath','油浴','Oil bath'],
    ['iceBath','冰浴','Ice bath'], ['tripod','三腳架','Tripod'], ['gauze','金屬網','Wire gauze'],
    ['stand','鐵架台及夾具','Retort stand with clamp','stand'], ['clamp','鐵夾','Clamp'],
    ['rack','試管架','Test tube rack','rack'], ['holder','試管夾','Test tube holder'],
    ['tongs','坩堝鉗','Crucible tongs'], ['spatula','藥匙','Spatula'],
    ['stirrer','磁力攪拌器','Magnetic stirrer','stirrer'], ['stirBar','磁力攪拌子','Stir bar']
  ],
  '量度與分析 Instruments': [
    ['balance','電子天平','Electronic balance','balance'], ['thermometer','溫度計','Thermometer','thermometer'],
    ['probe','溫度探針','Temperature probe','probe'], ['phMeter','酸鹼度探頭','pH meter probe','probe'],
    ['conductivityMeter','電導率計','Conductivity meter'], ['colorimeter','比色計','Colorimeter'],
    ['spectrometer','分光光度計','Spectrophotometer'], ['calorimeter','量熱器','Calorimeter','calorimeter',150],
    ['pressure','壓力感應器','Pressure sensor'], ['flowMeter','氣體流量計','Gas flow meter'],
    ['meltingPoint','熔點測定儀','Melting point apparatus'], ['chromatography','色譜裝置','Chromatography apparatus'],
    ['power','直流電源','DC power supply','power'], ['ammeter','安培計','Ammeter'],
    ['voltmeter','伏特計','Voltmeter'], ['electrodes','電極','Electrodes','electrode'],
    ['stopwatch','秒錶','Stopwatch','timer'], ['logger','數據記錄器','Data logger']
  ],
  '組合裝置 Assemblies': [
    ['filtration','過濾裝置','Filtration assembly'], ['pump','真空泵','Vacuum pump'],
    ['distillation','蒸餾裝置','Distillation apparatus'], ['reflux','回流裝置','Reflux apparatus'],
    ['gasCollection','氣體收集裝置','Gas collection assembly'], ['gasJar','集氣瓶','Gas jar','gasjar'],
    ['cell','電解槽','Electrolysis cell','cell',200], ['chemicalCell','化學電池','Chemical cell'],
    ['saltBridge','鹽橋','Salt bridge'], ['hood','通風櫥','Fume cupboard'], ['waste','廢物容器','Waste container']
  ],
  '實驗室設施 Lab fixtures': [
    ['sink','水槽與水龍頭','Sink and tap'], ['gasTap','氣體龍頭','Gas tap'], ['socket','電源插座','Power socket'],
    ['cabinet','儲物櫃','Storage cabinet'], ['shelf','試劑架','Reagent shelf'], ['ventilation','通風設備','Ventilation'],
    ['shower','緊急淋浴器','Emergency shower'], ['eyewash','洗眼器','Eyewash station'],
    ['extinguisher','滅火筒','Fire extinguisher'], ['blanket','滅火氈','Fire blanket'], ['firstAid','急救箱','First aid kit'],
    ['signs','危險標誌','Hazard signs'], ['exit','出口','Exit']
  ]
};
const glass = new Set(['beaker','flask','bottle','tube','burette','dropper','pipette','cylinder','funnel','gasjar']);
export const equipment = Object.entries(equipmentGroups).flatMap(([category, rows]) =>
  rows.map(([id,zh,en,kind=null,capacity=null]) => ({
    id, zh, en, kind, category, capacity, usable: Boolean(kind),
    material: glass.has(kind) ? 'glass' : null,
    actions: kind ? (capacity ? ['place','rotate','fill','pour'] : ['place','rotate']) : [],
    constraints: capacity ? '虛擬容量上限；超出部分另記外洩量。' : kind ? '可擺放；專用讀數視實驗模型而定。' : '器材圖鑑；功能待建模。',
    precision: null, provenance: apparatusSource
  }))
);

const substances = {
  '酸 Acids': [
    ['hcl','鹽酸','Hydrochloric acid','HCl'], ['sulfuric','硫酸','Sulfuric acid','H2SO4'],
    ['nitric','硝酸','Nitric acid','HNO3'], ['ethanoic','乙酸','Ethanoic acid','CH3COOH'],
    ['carbonic','碳酸','Carbonic acid','H2CO3'], ['phosphoric','磷酸','Phosphoric acid','H3PO4'],
    ['methanoic','甲酸','Methanoic acid','HCOOH'], ['citric','檸檬酸','Citric acid','C6H8O7']
  ],
  '鹽基與鹼 Bases': [
    ['naoh','氫氧化鈉','Sodium hydroxide','NaOH'], ['koh','氫氧化鉀','Potassium hydroxide','KOH'],
    ['ammoniaAq','氨水','Aqueous ammonia','NH3'], ['calciumHydroxide','氫氧化鈣','Calcium hydroxide','Ca(OH)2'],
    ['magnesiumHydroxide','氫氧化鎂','Magnesium hydroxide','Mg(OH)2'], ['sodiumCarbonate','碳酸鈉','Sodium carbonate','Na2CO3'],
    ['sodiumBicarbonate','碳酸氫鈉','Sodium hydrogencarbonate','NaHCO3'], ['magnesiumOxide','氧化鎂','Magnesium oxide','MgO'],
    ['copperOxide','氧化銅(II)','Copper(II) oxide','CuO']
  ],
  '鹽 Salts': [
    ['nacl','氯化鈉','Sodium chloride','NaCl'], ['kcl','氯化鉀','Potassium chloride','KCl'],
    ['copperSulfate','硫酸銅(II)','Copper(II) sulfate','CuSO4'], ['ironSulfate','硫酸鐵(II)','Iron(II) sulfate','FeSO4'],
    ['ironChloride','氯化鐵(III)','Iron(III) chloride','FeCl3'], ['zincSulfate','硫酸鋅','Zinc sulfate','ZnSO4'],
    ['magnesiumSulfate','硫酸鎂','Magnesium sulfate','MgSO4'], ['calciumChloride','氯化鈣','Calcium chloride','CaCl2'],
    ['silverNitrate','硝酸銀','Silver nitrate','AgNO3'], ['bariumChloride','氯化鋇','Barium chloride','BaCl2'],
    ['sodiumSulfate','硫酸鈉','Sodium sulfate','Na2SO4'], ['sodiumNitrate','硝酸鈉','Sodium nitrate','NaNO3'],
    ['potassiumNitrate','硝酸鉀','Potassium nitrate','KNO3'], ['ammoniumChloride','氯化銨','Ammonium chloride','NH4Cl'],
    ['ammoniumSulfate','硫酸銨','Ammonium sulfate','(NH4)2SO4'], ['potassiumIodide','碘化鉀','Potassium iodide','KI'],
    ['leadNitrate','硝酸鉛(II)','Lead(II) nitrate','Pb(NO3)2'], ['permanganate','過錳酸鉀','Potassium manganate(VII)','KMnO4'],
    ['dichromate','重鉻酸鉀','Potassium dichromate(VI)','K2Cr2O7'], ['thiosulfate','硫代硫酸鈉','Sodium thiosulfate','Na2S2O3']
  ],
  '金屬與固體 Solids': [
    ['mg','鎂','Magnesium','Mg'], ['zn','鋅','Zinc','Zn'], ['fe','鐵','Iron','Fe'], ['cu','銅','Copper','Cu'],
    ['al','鋁','Aluminium','Al'], ['ca','鈣','Calcium','Ca'], ['na','鈉','Sodium','Na'], ['k','鉀','Potassium','K'],
    ['c','碳','Carbon','C'], ['s','硫','Sulfur','S8'], ['calciumCarbonate','碳酸鈣','Calcium carbonate','CaCO3'],
    ['silica','二氧化硅','Silicon dioxide','SiO2'], ['manganeseOxide','二氧化錳','Manganese(IV) oxide','MnO2']
  ],
  '指示劑 Indicators': [
    ['phenolphthalein','酚酞','Phenolphthalein','C20H14O4'], ['methylOrange','甲基橙','Methyl orange','C14H14N3NaO3S'],
    ['methylRed','甲基紅','Methyl red','C15H15N3O2'], ['universal','通用指示劑','Universal indicator',null],
    ['litmus','石蕊','Litmus',null], ['bromothymolBlue','溴百里酚藍','Bromothymol blue','C27H28Br2O5S'],
    ['starchIndicator','澱粉指示劑','Starch indicator',null]
  ],
  '氣體 Gases': [
    ['hydrogen','氫','Hydrogen','H2'], ['oxygen','氧','Oxygen','O2'], ['carbonDioxide','二氧化碳','Carbon dioxide','CO2'],
    ['nitrogen','氮','Nitrogen','N2'], ['ammonia','氨','Ammonia','NH3'], ['chlorine','氯','Chlorine','Cl2'],
    ['sulfurDioxide','二氧化硫','Sulfur dioxide','SO2'], ['hydrogenChloride','氯化氫','Hydrogen chloride','HCl'],
    ['waterVapour','水蒸氣','Water vapour','H2O']
  ],
  '有機化合物 Organic': [
    ['methane','甲烷','Methane','CH4'], ['ethane','乙烷','Ethane','C2H6'], ['propane','丙烷','Propane','C3H8'],
    ['hexane','己烷','Hexane','C6H14'], ['ethene','乙烯','Ethene','C2H4'], ['propene','丙烯','Propene','C3H6'],
    ['methanol','甲醇','Methanol','CH3OH'], ['ethanol','乙醇','Ethanol','C2H5OH'], ['propanol','丙-1-醇','Propan-1-ol','C3H7OH'],
    ['ethylEthanoate','乙酸乙酯','Ethyl ethanoate','C4H8O2'], ['ethanal','乙醛','Ethanal','CH3CHO'],
    ['propanone','丙酮','Propanone','CH3COCH3'], ['bromoethane','溴乙烷','Bromoethane','C2H5Br'],
    ['benzene','苯','Benzene','C6H6'], ['polyethene','聚乙烯','Poly(ethene)','(C2H4)n'],
    ['pvc','聚氯乙烯','Poly(vinyl chloride)','(C2H3Cl)n']
  ],
  '其他 Reagents': [
    ['water','蒸餾水／去離子水','Distilled / deionised water','H2O'], ['bromineWater','溴水','Bromine water','Br2'],
    ['peroxide','過氧化氫溶液','Hydrogen peroxide solution','H2O2'], ['limewater','石灰水','Limewater','Ca(OH)2'],
    ['starchSolution','澱粉溶液','Starch solution',null], ['iodineSolution','碘溶液','Iodine solution',null],
    ['buffers','緩衝溶液','Buffer solutions',null], ['chromSolvents','色譜溶劑','Chromatography solvents',null],
    ['dryingAgents','乾燥劑','Drying agents',null]
  ]
};

const atomicWeights = {H:1.008,C:12.011,N:14.007,O:15.999,Na:22.990,Mg:24.305,Al:26.982,Si:28.085,P:30.974,S:32.06,Cl:35.45,K:39.098,Ca:40.078,Cr:51.996,Mn:54.938,Fe:55.845,Cu:63.546,Zn:65.38,Br:79.904,Ag:107.87,I:126.90,Ba:137.33,Pb:207.2};
function formulaMass(formula) {
  if (!formula || formula.endsWith('n')) return null;
  const groups=[0], tokens=formula.match(/[A-Z][a-z]?|\d+|[()]/g);
  for (let i=0;i<tokens.length;i++) {
    const token=tokens[i];
    if (token==='(') { groups.push(0);continue; }
    const base=token===')' ? groups.pop() : atomicWeights[token];
    if (base===undefined) throw new Error('Unknown element in registry: '+token);
    const factor=/^\d+$/.test(tokens[i+1]||'') ? Number(tokens[++i]) : 1;
    groups[groups.length-1]+=base*factor;
  }
  return Number(groups[0].toFixed(2));
}
const displayFormula = s => s ? s.replace(/\d/g, n => '₀₁₂₃₄₅₆₇₈₉'[Number(n)]).replace(/\)n$/,')ₙ') : '—';
const stockConcentration = new Map([['water',0],['hcl',0.1000],['naoh',0.1000],['nacl',0.1000]]);
const aq = new Set(['hcl','naoh','nacl','ammoniaAq','carbonic','bromineWater','peroxide','limewater','iodineSolution','buffers','starchSolution']);
const liquids = new Set(['water','methanol','ethanol','propanol','hexane','ethylEthanoate','propanone','bromoethane','benzene','ethanoic','methanoic','sulfuric','nitric']);
const gases = new Set(['methane','ethane','propane','ethene','propene','ethanal']);
const protectedMaterials = new Set(['na','k','chlorine','hydrogenChloride','bromineWater','benzene','leadNitrate','dichromate','bariumChloride','sulfurDioxide']);
const guideUse = {
  hcl:['titration','heat','rate'], naoh:['titration','heat','analysis'], copperSulfate:['electrolysis'],
  phenolphthalein:['titration'], ammoniaAq:['analysis'], calciumCarbonate:['rate']
};
export const chemicals = Object.entries(substances).flatMap(([category,rows]) =>
  rows.map(([id,zh,en,rawFormula])=>{
    const usable=stockConcentration.has(id);
    const state=aq.has(id) ? 'aq' : category.startsWith('氣體') || gases.has(id) ? 'g' : liquids.has(id) ? 'l' :
      category.startsWith('鹽 ') || category.startsWith('金屬') || ['silica','pvc','polyethene','citric','phosphoric','magnesiumOxide','copperOxide','magnesiumHydroxide','sodiumBicarbonate','sodiumCarbonate','calciumHydroxide','koh'].includes(id) ? 's' : null;
    return {
      id, zh, en, formula:displayFormula(rawFormula), rawFormula, category, categories:
        ['ethanoic','methanoic'].includes(id) ? [category,'有機化合物 Organic'] : [category],
      usable, state, molarMass:formulaMass(rawFormula), molarMassUnit:'g mol⁻¹',
      // For mixtures with a displayed solute, molar mass belongs only to that solute.
      concentration:usable && id!=='water' ? stockConcentration.get(id) : null,
      supportedExperiments:guideUse[id]||[], safety:protectedMaterials.has(id)?'限固定教學情境；自由混合停用。':usable?'僅模擬所列稀溶液及理想水溶液。':'圖鑑用途；自由混合停用。',
      provenance:'Word §7；式量以 CIAAW 簡表計算（名義化學式，鹽類以列出的水合狀態為準）。其他物性未核實時保留空值。',
      density:null,solubility:null
    };
  })
);
export const inventorySources = {
  atomicWeights:'https://ciaaw.org/abridged-atomic-weights.htm',
  acidBase:'https://openstax.org/books/chemistry-2e/pages/14-key-equations',
  titration:'https://openstax.org/books/chemistry-2e/pages/14-7-acid-base-titrations'
};

// The three analytical totals are delivered moles, including neutralised portions.
// A charge balance and water equilibrium recover free ions without destroying
// the history needed to check sodium and chloride conservation after a pour.
const stockKeys=['hcl','naoh','nacl'];
export function emptySolution() {return {volume:0,hcl:0,naoh:0,nacl:0};}
function nonnegative(value,label) {
  if(typeof value!=='number' || !Number.isFinite(value) || value<0) throw new RangeError('Invalid '+label);
  return value;
}
function checkSolution(s) {
  if(!s || typeof s!=='object') throw new TypeError('Missing solution');
  for(const key of ['volume',...stockKeys]) nonnegative(s[key],key);
  if (s.volume===0 && stockKeys.some(k=>s[k]>0)) throw new RangeError('Empty vessel contains nonzero moles');
}
function portion(s,volume) {
  if(volume===0 || s.volume===0) return emptySolution();
  const f=volume/s.volume;
  return {volume,hcl:s.hcl*f,naoh:s.naoh*f,nacl:s.nacl*f};
}
function combine(a,b) {
  return {volume:a.volume+b.volume,hcl:a.hcl+b.hcl,naoh:a.naoh+b.naoh,nacl:a.nacl+b.nacl};
}
// Overflow is measured at the lip: with a full receiving vessel, incoming
// liquid misses it; no displacement of the previously collected liquid.
export function pour(source,destination,requestedMl,destinationCapacityMl) {
  checkSolution(source);checkSolution(destination);
  nonnegative(requestedMl,'requested volume');nonnegative(destinationCapacityMl,'capacity');
  if(source===destination) throw new RangeError('Choose two different vessels');
  if(destination.volume>destinationCapacityMl+1e-9) throw new RangeError('Destination already exceeds capacity');
  const transferred=Math.min(source.volume, requestedMl);
  const accepted=Math.min(transferred,Math.max(0,destinationCapacityMl-destination.volume));
  const overflow=transferred-accepted;
  return {source:portion(source,source.volume-transferred), destination:combine(destination,portion(source,accepted)),
    spill:portion(source,overflow), transferred,accepted,overflow};
}
export function addStock(solution,stockId,amountMl,capacityMl) {
  if(!stockConcentration.has(stockId)) throw new RangeError('此試劑未有可用的自由混合模型。');
  nonnegative(amountMl,'stock volume');
  const aliquot=emptySolution();
  aliquot.volume=amountMl;
  if(stockId!=='water') aliquot[stockId]=stockConcentration.get(stockId)*amountMl/1000;
  const result=pour(aliquot,solution,amountMl,capacityMl);
  return {solution:result.destination,spill:result.spill,accepted:result.accepted,overflow:result.overflow};
}
export function readSolution(s) {
  checkSolution(s);
  const net=s.hcl-s.naoh;
  const excess=s.volume ? net*1000/s.volume : 0;
  const kw=1e-14;
  const radius=Math.hypot(excess,2*Math.sqrt(kw));
  // Algebraically equivalent roots selected by sign to avoid cancellation.
  const h=excess>=0 ? (excess+radius)/2 : 2*kw/(radius-excess);
  return {volume:s.volume,pH:s.volume ? -Math.log10(h) : null,acidExcess:Math.max(net,0),
    baseExcess:Math.max(-net,0),sodium:s.naoh+s.nacl,chloride:s.hcl+s.nacl};
}
