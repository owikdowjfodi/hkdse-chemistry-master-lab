import {applyModel} from './model.js';
self.onmessage=({data:{state,cmd,value,token}})=>{try{self.postMessage({state:applyModel(state,cmd,value),token})}catch(error){self.postMessage({error:error.message,token})}};
