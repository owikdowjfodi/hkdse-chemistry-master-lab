// Interactive, locally rendered three-dimensional teaching apparatus.
// Coordinates and dimensions are scene units. Liquid fractions and colour come from the model.
const TAU = 2 * Math.PI;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const palette = {
  steel:'#899ca2', chrome:'#d6e2e1', shadow:'#344b55', cast:'#414e54', porcelain:'#eff5f3',
  glass:'#a7d7db', rim:'#527f86', glassLight:'#faffff', blue:'#077c99', blueDark:'#15576e',
  teal:'#22a8aa', black:'#37454b', white:'#f6faf8', amber:'#92512c'
};
const rgbCache = new Map();
function rgb(s) {
  if (rgbCache.has(s)) return rgbCache.get(s);
  let result = [0.33,0.74,0.81];
  if (typeof s === 'string' && /^#([\da-f]{3}|[\da-f]{6})$/i.test(s)) {
    let v=s.slice(1); if(v.length===3) v=[...v].map(c=>c+c).join('');
    result=[0,2,4].map(i=>parseInt(v.slice(i,i+2),16)/255);
  } else if (typeof s === 'string' && /^rgba?\(/.test(s)) {
    const n=s.match(/[\d.]+/g); if(n?.length>=3) result=n.slice(0,3).map(t=>clamp(+t/255,0,1));
  }
  rgbCache.set(s,result); return result;
}
function norm(v) { const l=Math.hypot(...v)||1; return v.map(x=>x/l); }
const sub = (a,b)=>a.map((v,i)=>v-b[i]);
const dot = (a,b)=>a.reduce((v,k,i)=>v+k*b[i],0);
const cross = (a,b)=>[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]];
const sun = norm([-0.65,1,0.7]);
const tidy = s=>String(s||'beaker').toLowerCase().replace(/[\s_-]+/g,'');
function typeOf(kind){
  const k=tidy(kind);
  if(/burett/.test(k))return 'burette';
  if(/stand|retort|clamp/.test(k))return 'stand';
  if(/conical|erlenmeyer|flask/.test(k))return 'flask';
  if(/syringe/.test(k))return 'syringe';
  if(/rack|tubestand/.test(k))return 'rack';
  if(/testtube|boilingtube|^tube$/.test(k))return 'tube';
  if(/reagent|bottle|reservoir/.test(k))return 'bottle';
  if(/pipet|dropper|rod/.test(k))return 'pipette';
  if(/thermo|probe|sensor|phmeter/.test(k))return 'probe';
  if(/balance|scales?/.test(k))return 'balance';
  if(/power|battery|supply|ammeter|voltmeter/.test(k))return 'power';
  if(/electrode/.test(k))return 'electrode';
  if(/cell|electroly/.test(k))return 'cell';
  if(/calorim|insulat|cup/.test(k))return 'calorimeter';
  if(/burner|bunsen/.test(k))return 'burner';
  if(/plate|stirrer|bath/.test(k))return 'plate';
  if(/gasjar|gascollect|chamber|equilibrium|gasvessel/.test(k))return 'gasjar';
  if(/cylinder/.test(k))return 'cylinder';
  if(/funnel/.test(k)) return 'funnel';
  if(/stopwatch|timer|clock/.test(k))return 'timer';
  if(/beaker|vessel|reactor|solution/.test(k))return 'beaker';
  return 'generic';
}
const dims={
  stand:[1.08,3.31],burette:[.29,3.44],flask:[.91,1.13],beaker:[.79,.86],bottle:[.53,1.01],tube:[.24,1],rack:[1.03,.74],
  pipette:[.25,1.52],probe:[.26,1.26],balance:[1,.48],power:[.88,.69],cell:[.95,1.13],electrode:[.32,1.06],
  calorimeter:[.82,1.05],syringe:[1.31,.6],burner:[.54,.86],plate:[.95,.35],gasjar:[.69,1.15],cylinder:[.46,1.16],funnel:[.69,.94],timer:[.5,.55],generic:[.54,.6]
};
const limits={x:3.72,z:1.62};
function worldGeometry(state, drag, animation) {
  const prim=[], targets=[];
  let x0=0,z0=0,rot=0,layer=0;
  const world=p=>[x0+p[0]*Math.cos(rot)+p[2]*Math.sin(rot),p[1],z0-p[0]*Math.sin(rot)+p[2]*Math.cos(rot)];
  function face(p,col,alpha=1,shade=true) {
    const v=p.map(world);
    let brightness=1;
    if(shade){const n=norm(cross(sub(v[1],v[0]),sub(v[2],v[0])));brightness=.83+.21*Math.abs(dot(n,sun))+.04*Math.max(0,n[1]);}
    prim.push({v,col:rgb(col).map(k=>Math.min(1,k*brightness)),alpha, layer});
  }
  function line(a,b,col,alpha=1,width=1) {prim.push({v:[world(a),world(b)],col:rgb(col),alpha,width,layer});}
  function textAt(p,txt,col='#3f6670',size=.066) {prim.push({v:[world(p)],label:txt,col,alpha:1,size,layer});}
  const at=(r,y,t,ox=0,oz=0)=>[ox+r*Math.cos(t),y,oz+r*Math.sin(t)];
  function ring(r,y,col,alpha=1,width=1,ox=0,oz=0,n=36){
    for(let i=0;i<n;i++)line(at(r,y,TAU*i/n,ox,oz),at(r,y,TAU*(i+1)/n,ox,oz),col,alpha,width);
  }
  function disk(r,y,col,alpha=1,ox=0,oz=0,n=32) {
    for(let i=0;i<n;i++)face([[ox,y,oz],at(r,y,TAU*i/n,ox,oz),at(r,y,TAU*(i+1)/n,ox,oz)],col,alpha,false);
  }
  function lathe(profile,col,alpha=1,ox=0,oz=0,n=32){
    for(let j=0;j<profile.length-1;j++){
      const [r,y]=profile[j], [r2,y2]=profile[j+1];
      for(let i=0;i<n;i++){
        const a=TAU*i/n,b=TAU*(i+1)/n;
        face([at(r,y,a,ox,oz),at(r,y,b,ox,oz),at(r2,y2,b,ox,oz),at(r2,y2,a,ox,oz)],col,alpha);
      }
    }
  }
  function cyl(x,z,y,r,h,col,n=24){
    lathe([[r*.96,y],[r,y+.009],[r,y+h-.009],[r*.96,y+h]],col,1,x,z,n);
    disk(r*.96,y+h,col,1,x,z,n);
  }
  function box(x,y,z,w,h,d,col){
    const a=x-w/2,b=x+w/2,c=z-d/2,e=z+d/2,f=y+h;
    face([[a,y,c],[a,y,e],[a,f,e],[a,f,c]],col);
    face([[b,y,e],[b,y,c],[b,f,c],[b,f,e]],col);
    face([[a,y,e],[b,y,e],[b,f,e],[a,f,e]],col);
    face([[b,y,c],[a,y,c],[a,f,c],[b,f,c]],col);
    face([[a,f,e],[b,f,e],[b,f,c],[a,f,c]],col);
  }
  function pipe(a,b,r,col,n=12){
    const dir=norm(sub(b,a)), side=norm(cross(dir,Math.abs(dir[1])>.9?[1,0,0]:[0,1,0])),up=cross(dir,side);
    const point=(p,t)=>p.map((v,k)=>v+r*(side[k]*Math.cos(t)+up[k]*Math.sin(t)));
    for(let i=0;i<n;i++)face([point(a,i*TAU/n),point(a,(i+1)*TAU/n),point(b,(i+1)*TAU/n),point(b,i*TAU/n)],col);
  }
  // A quiet, daylight teaching lab. The room, rear fittings and main work surface are independent depth layers.
  layer=-8;
  box(0,-1.18,-5.9,27,7,.08,'#dde9e8');
  layer=-7;
  for(let i=-10;i<=10;i++)line([i,-.2,-5.8],[i,3.0,-5.8],'#9fb5b7',.25,.75);
  for(let i=0;i<=5;i++)line([-12,i*.55,-5.8],[12,i*.55,-5.8],'#a8bbbb',.29,.75);
  layer=-6;
  for(let i=0;i<5;i++){
    const x=-4.65+i*1.06;
    box(x,1.24,-5.69,1.06,1.52,.085,'#eff7f4');
    box(x,1.29,-5.62,.97,1.42,.03,'#d1e7e7');
    for(let j=0;j<5;j++)
      line([x-.46,1.43+j*.23,-5.589],[x+.45,1.43+j*.23,-5.589],'#e5f0ef',.69,1.25);
  }
  box(-2.52,1.195,-5.56,5.43,.048,.20,'#c7dbd8');
  // Emergency eyewash sign above the sink and an outlet on the tiled backsplash.
  box(1.28,1.07,-5.65,.43,.37,.035,'#49887b');
  box(1.28,1.135,-5.619,.058,.23,.008,'#edf6ef');
  box(1.28,1.222,-5.611,.225,.058,.008,'#edf6ef');
  box(.39,.74,-5.64,.31,.18,.026,'#f0f2ea');
  for(const dx of [-.07,.07]){
    box(.39+dx,.802,-5.616,.018,.047,.012,'#819392');
  }
  layer=-4;
  box(0,-1.22,-4.7,22,1.53,1.43,'#b5c9c9');
  box(0,.30,-4.70,22,.095,1.55,'#a4b8b9');
  for(let i=-9;i<10;i++){
    box(i,-1.12,-3.963,.965,1.30,.027,i%2?'#c4d5d3':'#ccdcd9');
    box(i+.28,-.03,-3.918,.28,.032,.05,'#8a9fa0');
  }
  box(3.1,.391,-4.69,1.2,.014,.72,'#86999b'); box(3.1,.407,-4.69,1.03,.01,.55,'#b5c6c4');
  const faucet=[[3.37,.41,-4.98],[3.37,.93,-4.98],[3.35,1.01,-4.91],[3.33,1.025,-4.65],[3.33,.92,-4.62]];
  faucet.slice(1).forEach((p,i)=>pipe(faucet[i],p,.034,'#91aaa9'));
  // Stationary reference props sit on the rear counter.
  layer=-3.5;
  for(const [px,pz,r,h] of [[-2.98,-4.8,.104,.42],[-2.68,-4.74,.115,.46],[-2.38,-4.78,.10,.34]]){
    lathe([[r*.9,.40],[r,.42],[r,.40+h*.76],[r*.54,.4+h*.89],[r*.51,.4+h]],'#c2d2cf',1,px,pz,12);
    cyl(px,pz,.40+h,r*.57,.055,'#819e9e',12);
    lathe([[r+.002,.50],[r+.002,.62]],'#e5ece6',1,px,pz,12);
  }
  layer=-3;
  box(0,-.21,0,9,.20,4.25,'#97afae');
  box(0,-.085,0,9.03,.078,4.29,'#c9dcd9');
  // A fine inlaid grid provides position cues when moving instruments.
  for(let i=-8;i<=8;i++)line([i*.5,-.003,-2.125],[i*.5,-.003,2.125],'#8ba7a6',.19,.7);
  for(let j=-4;j<=4;j++)line([-4.5,-.003,j*.5],[4.5,-.003,j*.5],'#8ba7a6',.19,.7);
  function contact(x,z,r,depth=1) {
    for(let k=5;k>=1;k--){
      const scale=r*(.66+k*.15), n=30;
      const pts=Array.from({length:n},(_,i)=>[x+scale*Math.cos(i*TAU/n)+scale*.10,.002,z+scale*.54*Math.sin(i*TAU/n)+scale*.025]);
      face(pts,'#3e6067',depth*.053,false);
    }
  }
  function glass(profile,fill,color,ox=0,oz=0){
    // Liquid volume maps to the integral of the internal frustum cross-sections.
    const fraction=clamp(Number(fill)||0,0,1);
    const vol=(a,b,h)=>Math.PI*h*(a*a+a*b+b*b)/3;
    const seg=profile.slice(1).map(([r1,h1],i)=>vol(profile[i][0],r1,h1-profile[i][1]));
    if(fraction>0){
      let remain=seg.reduce((a,b)=>a+b,0)*fraction,liquid=[[profile[0][0]*.96,profile[0][1]+.005]];
      for(let i=0;i<seg.length;i++){
        const [a,y]=profile[i],[b,z]=profile[i+1];
        if(remain>=seg[i]){liquid.push([b*.96,z]);remain-=seg[i];continue;}
        let l=0,h=1;
        for(let n=0;n<12;n++){const t=(h+l)/2,tv=vol(a,a+(b-a)*t,(z-y)*t);if(tv<remain)l=t;else h=t;}
        const t=(l+h)/2;liquid.push([(a+(b-a)*t)*.96,y+(z-y)*t]); break;
      }
      const [lr,ly]=liquid[liquid.length-1];
      lathe(liquid,color||'#b1dcde',.43,ox,oz);disk(lr,ly,color||'#aed7d8',.64,ox,oz);
      ring(lr,ly,'#f3ffff',.75,.9,ox,oz);
    }
    lathe(profile,palette.glass,.095,ox,oz);
    const [base,bottom]=profile[0],[top,y]=profile[profile.length-1];
    ring(base,bottom,palette.rim,.52,1.1,ox,oz);ring(top,y,palette.rim,.78,1.7,ox,oz);
    ring(top*.93,y+.007,palette.glassLight,.95,.9,ox,oz);
    for(const [theta,col,alpha,thick] of [[.12,palette.rim,.62,1.2],[2.98,palette.rim,.59,1.2],[2.39,palette.glassLight,.92,2.3],[.63,palette.glassLight,.85,1.45]]){
      for(let j=0;j<profile.length-1;j++){
        const [r1,h1]=profile[j],[r2,h2]=profile[j+1];
        line(at(r1,h1,theta,ox,oz),at(r2,h2,theta,ox,oz),col,alpha,thick);
      }
    }
  }
  function graduations(radius,bottom,top,count,direction=1,ox=0,oz=0,majorEvery=5,labelStep=10){
    const startAngle=.96;
    for(let i=0;i<=count;i++){
      const y=bottom+(top-bottom)*i/count,major=i%majorEvery===0;
      const a=at(radius+.002,y,startAngle,ox,oz),b=at(radius+.002,y,startAngle+(major?.94:.48),ox,oz);
      line(a,b,'#345962',major?.85:.62,major?1.08:.78);
      if(major && count>=20)textAt([a[0]+.029,y+.005,a[2]+.012],String((direction===-1?count-i:i)/majorEvery*labelStep),'#3c5b64',.061);
    }
  }
  function vessel(k,f,c,item) {
    if(k==='flask'){
      glass([[.33,.025],[.395,.06],[.414,.115],[.402,.175],[.182,.649],[.144,.742],[.14,1.025],[.162,1.045],[.162,1.083]],f,c);
      ring(.403,.104,palette.glassLight,.85,1.2);
      for(const [y,r] of [[.20,.39],[.275,.353],[.35,.319],[.425,.28]])line(at(r,y,1.27),at(r,y,1.92),'#629097',.85,1.1);
      textAt([.072,.35,.31],String(item.capacity||250)+' mL','#406c73',.073);
    }else if(k==='beaker'){
      glass([[.325,.015],[.357,.052],[.36,.752],[.369,.787],[.368,.797]],f,c);
      graduations(.361,.16,.68,10);textAt([.105,.48,.32],String(item.capacity||250)+' mL','#406c73',.06);
      line([-.29,.793,.208],[-.372,.805,.14],palette.rim,.62,1.5);
    }else if(k==='burette'){
      const base=1.61,top=3.49;
      glass([[.051,base],[.065,base+.06],[.066,top-.036],[.079,top-.019],[.079,top]],0,c);
      if(Number(f)>0){
        const y=base+.11+(top-.14-base-.11)*clamp(Number(f),0,1);
        lathe([[.049,base+.007],[.063,base+.065],[.063,y]],c||'#acd4d7',.38);
        disk(.063,y,c||'#acd4d7',.62);
        ring(.063,y,'#527d85',.82,.9);
      }
      graduations(.068,base+.11,top-.14,50,-1,0,0,10);
      lathe([[.028,1.23],[.032,1.39],[.057,1.51],[.056,base]],'#bee0df',.60);
      pipe([-.106,1.52,0],[.108,1.52,0],.064,palette.white);
      pipe([-.02,1.52,.04],[-.02,1.52,.112],.044,palette.blueDark);
      box(-.02,1.49,.12,.213,.056,.048,palette.blue);
      ring(.027,1.235,palette.rim,.83,.9);
    }else if(k==='bottle'){
      lathe([[.178,.016],[.214,.048],[.215,.65],[.196,.706],[.108,.779],[.101,.846]],'#abc9c6',.68);
      cyl(0,0,.819,.126,.141,palette.blue,26);
      for(let j=0;j<12;j++)line(at(.126,.839,j*TAU/12),at(.126,.94,j*TAU/12),palette.blueDark,.75,.8);
      lathe([[.217,.228],[.217,.507]],'#f9faf2',.96);
      textAt([.019,.366,.22],'REAGENT','#466368',.058);
    }else if(k==='tube'){
      glass([[.015,.03],[.069,.052],[.094,.105],[.097,.932],[.11,.951]],f,c);
    }else if(k==='gasjar'){
      glass([[.277,.036],[.301,.076],[.304,.97],[.257,1.007],[.254,1.061]],f,c);cyl(0,0,1.062,.283,.049,'#a1b4b3');
    }else if(k==='cylinder'){
      cyl(0,0,.015,.225,.065,'#b7cecc',6);glass([[.127,.08],[.133,.13],[.133,1.12],[.15,1.15]],f,c);graduations(.133,.2,1.02,20,1,0,0,5,25);
    }
  }
  for(const item of state.items||[]){
    const k=typeOf(item.kind),[w,h]=dims[k],sel=state.selected===item.id;
    x0=drag?.id===item.id?drag.x:(Number(item.x)||0);z0=drag?.id===item.id?drag.z:(Number(item.z)||0);
    rot=Number(item.rotation)||0;if(Math.abs(rot)>TAU+.01)rot*=Math.PI/180;
    targets.push({id:item.id,k,x:x0,z:z0,w,h});
    layer=-2; if(k!=='burette')contact(0,0,w*.58);
    if(sel && k!=='burette')ring(w*.57,.008,'#168f8c',.63,1.35,0,0,44);
    layer=0;
    const f=item.fill,c=item.color||'#a5d5da';
    if(item.broken){
      for(let i=0;i<9;i++){const a=i*2.39,d=.14+(i%3)*.081;face([[Math.cos(a)*d, .012,Math.sin(a)*d],[Math.cos(a+.75)*(d+.13),.025,Math.sin(a+.75)*(d+.13)],[Math.cos(a-.3)*(d+.03),.095,Math.sin(a-.3)*(d+.03)]],palette.glass,.81);}
    }else if(['flask','beaker','burette','bottle','tube','gasjar','cylinder'].includes(k)){
      vessel(k,f,c,item);
      if(item.precipitate&&['beaker','tube','flask'].includes(k)){
        const radius=k==='tube'?.072:.22;
        lathe([[radius*.58,.032],[radius,.072],[radius*.85,.115]],item.precipitateColor||'#dee5db',.91);
        disk(radius*.85,.115,item.precipitateColor||'#eceee2',.88);
      }
    }else if(k==='stand'){
      box(0,.015,.05,1.01,.096,.60,palette.cast);
      box(0,.11,.05,.995,.013,.59,'#748384');
      cyl(0,-.105,.125,.11,.112,palette.black);
      cyl(0,-.105,.236,.038,3.00,palette.chrome);
      const m=(state.items||[]).find(j=>typeOf(j.kind)==='burette' && Math.hypot((j.x||0)-x0,(j.z||0)-z0)<1.52);
      const dx=m?(Number(m.x)||0)-x0:0, dz=m?(Number(m.z)||0)-z0:0;
      const aim=m?[dx*Math.cos(rot)-dz*Math.sin(rot),2.48,dx*Math.sin(rot)+dz*Math.cos(rot)]:[.59,2.48,-.095];
      const armStart=[0,2.43,-.105];
      box(0,2.352,-.106,.15,.20,.136,palette.blueDark);
      pipe([-.125,2.43,-.105],[.116,2.43,-.105],.033,palette.chrome);
      pipe(armStart,aim,.036,'#7d9297');
      for(const side of [-1,1]){
        const a=[aim[0]-.12,2.48,aim[2]],b=[aim[0]-.04,2.49,aim[2]+side*.082],c=[aim[0]+.058,2.49,aim[2]+side*.058];
        pipe(a,b,.02,palette.steel);pipe(b,c,.025,palette.blue);
      }
      cyl(0,-.105,3.21,.043,.035,palette.steel);
    }else if(k==='rack'){
      box(0,.02,0,1.01,.075,.40,'#c9b68d');
      for(const a of [-.45,.45])box(a,.089,0,.05,.47,.34,'#c7b587');
      box(0,.49,0,.99,.055,.34,'#dac59c');
      for(const a of [-.30,0,.30]){
        glass([[.032,.09],[.071,.14],[.075,.69],[.085,.706]],a===0?f:0,c,a,0);ring(.089,.548,'#998760',.55,1,a);
      }
    }else if(k==='pipette'||k==='probe'){
      if(k==='pipette'){
        glass([[.009,.071],[.026,.30],[.03,.51],[.082,.64],[.086,.726],[.038,.84],[.032,1.28]],f,c);
        lathe([[.043,1.26],[.071,1.30],[.093,1.40],[.078,1.47],[.042,1.51]],palette.blue);
      }else{
        cyl(0,0,.035,.03,.92,palette.chrome);cyl(0,0,.90,.068,.31,palette.blueDark);
        cyl(0,0,1.20,.053,.046,palette.teal);
      }
    }else if(k==='power'||k==='balance'||k==='plate'){
      box(0,.015,0,w*.94,k==='power'?.59:.216,.65,'#d7e4df');
      box(0,.055,.333,w*.85,k==='power'?.43:.13,.024,'#566b6a');
      box(-.11,k==='power'?.31:.095,.350,k==='power'?.40:.31,.069,.009,'#b8dccb');
      if(k==='power'){for(const a of [-.18,.18])pipe([a,.18,.35],[a,.18,.395],.04,a<0?'#3c4447':'#b86e62');}
      else if(k==='balance'){cyl(0,0,.23,.33,.052,palette.chrome);disk(.305,.283,'#b4c5c5');}
      else cyl(0,0,.23,.36,.066,'#9baaae');
    }else if(k==='cell'){
      glass([[.37,.02],[.41,.055],[.41,.80],[.425,.826]],f,c);
      box(-.19,.12,0,.135,.91,.042,'#a56d53');box(.19,.12,0,.135,.91,.042,'#9f7867');
      if(Number(item.deposit)>0){
        box(.19,.14,.024,.14,.35,.009,'#c88257');
        for(let j=0;j<9;j++)line([.124,.16+j*.035,.034],[.255,.177+j*.035,.034],'#d9a47d',.72,.8);
      }
      if(item.bubbles){
        for(let j=0;j<7;j++){
          const dy=(j*.071+(state.lowMotion?0:animation*.1))%.43;
          ring(.017+(j%3)*.003,.16+dy,'#efffff',.95,1.25,-.17+Math.sin(j*2.37)*.04,.068,12);
        }
      }
      pipe([-.19,.98,0],[-.24,1.08,-.135],.022,'#a75d5a');pipe([.19,.98,0],[.27,1.06,-.16],.022,'#485f67');
    }else if(k==='electrode'){
      box(0,.02,0,.22,.94,.062,'#a77860');box(0,.91,0,.25,.12,.092,'#3e5c63');
    }else if(k==='calorimeter'){
      lathe([[.26,.015],[.31,.065],[.376,.70],[.39,.744]],'#ecf0e5');
      disk(.392,.744,'#d8e6dd');ring(.393,.745,'#8aa9a0',.9,1.4);
      pipe([.038,.74,0],[.048,1.14,0],.022,palette.steel);cyl(.048,0,1.12,.042,.11,palette.blue);
    }else if(k==='syringe'){
      box(0,.015,0,1.1,.075,.35,'#bccbc8');
      const edge=(x,t)=>[x,.39+.135*Math.sin(t),.135*Math.cos(t)];
      for(let j=0;j<26;j++){
        const a=j*TAU/26,b=(j+1)*TAU/26;
        face([edge(-.52,a),edge(-.52,b),edge(.52,b),edge(.52,a)],palette.glass,.13);
        line(edge(-.52,a),edge(-.52,b),palette.rim,.75,1);line(edge(.52,a),edge(.52,b),palette.rim,.75,1);
      }
      for(const a of [.29,1.4,4.6])line(edge(-.52,a),edge(.52,a),a<1?palette.glassLight:palette.rim,.78,1.3);
      pipe([-.68,.39,0],[-.52,.39,0],.04,palette.steel);
      const piston=-.46+.91*clamp(Number(f)||0,0,1);
      pipe([piston,.39,0],[piston+.045,.39,0],.122,palette.cast);
      pipe([piston+.045,.39,0],[piston+.77,.39,0],.033,palette.steel);
      pipe([piston+.77,.39,0],[piston+.802,.39,0],.132,palette.chrome);
      for(let i=0;i<=20;i++)line([-.46+i*.0455,.48,.08],[-.46+i*.0455,.445-(i%5===0?.039:0),.127],'#3e6369',.85,1);
    }else if(k==='burner'){
      cyl(0,0,.012,.25,.08,'#506976');lathe([[.147,.081],[.107,.17],[.073,.20],[.068,.76],[.079,.80]],'#90a4a8');
      ring(.079,.80,'#485b66',1,1.5);
    }else if(k==='funnel'){
      glass([[.027,.015],[.028,.46],[.315,.786],[.317,.803]],0,c);
    }else if(k==='timer'){
      box(0,.02,0,.47,.36,.20,'#526b70');box(0,.135,.11,.37,.17,.015,'#bedbcb');
    }else{
      box(0,.012,0,.44,.44,.385,'#baccc8');box(0,.46,0,.38,.04,.32,palette.steel);
    }
    if(state.effect && ((!state.effect.id&&!state.effect.target&&sel)||state.effect.id===item.id||state.effect.target===item.id)){
      const fx=String(typeof state.effect==='string'?state.effect:(state.effect.type||state.effect.kind||''));
      if(/spill|overflow/i.test(fx)){
        layer=-1;for(let j=0;j<3;j++)disk(.23-j*.048,.012+j*.001,c,.34,.31+j*.13,.13-j*.067);
      }else if(/bubble|gas/i.test(fx)&&!state.lowMotion){
        for(let j=0;j<6;j++)ring(.023, .18+(animation*.3+j*.079)%.48,'#ecffff',.9,1,Math.sin(j)*.16,Math.cos(j)*.15,12);
      }
    }
  }
  // Route model-confirmed electrical / gas connections through world-space attachment points.
  rot=0;x0=0;z0=0;layer=0;
  for(const item of state.items||[]){
    const k=typeOf(item.kind);
    if(!item.connected||!['cell','syringe'].includes(k))continue;
    const a=targets.find(t=>t.id===item.id);
    const b=targets.find(t=>t.k===(k==='cell'?'power':'flask'));
    if(!a||!b)continue;
    if(k==='cell'){
      for(const s of [-1,1]){
        const points=[[a.x+s*.19,.99,a.z],[a.x+s*.27,1.08,a.z-.15],[a.x+s*.34,.70,a.z-.25],[(a.x+b.x)/2,.075,(a.z+b.z)/2-.28],[b.x+s*.18,.18,b.z+.39]];
        points.slice(1).forEach((p,i)=>pipe(points[i],p,.016,s>0?'#956261':'#3c535c',8));
      }
    }else{
      const points=[[b.x,1.08,b.z],[b.x,1.19,b.z],[b.x+.12,1.24,b.z],[(a.x+b.x)/2,1.05,(a.z+b.z)/2],[a.x-.71,.47,a.z],[a.x-.68,.39,a.z]];
      points.slice(1).forEach((p,i)=>pipe(points[i],p,.029,'#758e91',10));
      cyl(b.x,b.z,1.051,.118,.052,'#6a7876',16);
    }
  }
  return {prim, targets};
}
const glyphs={
  '0':['111','101','101','101','111'],'1':['010','110','010','010','111'],'2':['111','001','111','100','111'],
  '3':['111','001','111','001','111'],'4':['101','101','111','001','001'],'5':['111','100','111','001','111'],
  '6':['111','100','111','101','111'],'7':['111','001','010','010','010'],'8':['111','101','111','101','111'],
  '9':['111','101','111','001','111'],'m':['000','000','11111','10101','10101'],'L':['100','100','100','100','111'],
  'R':['110','101','110','101','101'],'E':['111','100','110','100','111'],'A':['010','101','111','101','101'],
  'G':['111','100','101','101','111'],'N':['1001','1101','1011','1001','1001'],'T':['111','010','010','010','010']
};
function renderer(canvas){
  let gl=null;
  try{gl=canvas.getContext('webgl',{alpha:false,antialias:true,powerPreference:'low-power',preserveDrawingBuffer:false});}catch{}
  if(!gl){
    const ctx=canvas.getContext('2d');
    return {paint(prims,w,h,dpr){
      ctx.setTransform(dpr,0,0,dpr,0,0);
      ctx.fillStyle='#dfeae8';ctx.fillRect(0,0,w,h);ctx.lineJoin='round';ctx.lineCap='round';
      for(const p of prims){
        const co=p.label?p.col:'rgb('+p.col.map(c=>Math.round(c*255)).join(',')+')';
        ctx.globalAlpha=p.alpha;
        if(p.label){ctx.fillStyle=co;ctx.font=Math.max(4,p.sizePx)+'px sans-serif';ctx.fillText(p.label,p.scr[0][0],p.scr[0][1]);continue;}
        ctx.beginPath();ctx.moveTo(...p.scr[0]);
        for(let i=1;i<p.scr.length;i++)ctx.lineTo(...p.scr[i]);
        if(p.width){ctx.strokeStyle=co;ctx.lineWidth=p.width;ctx.stroke();}
        else{ctx.closePath();ctx.fillStyle=co;ctx.fill();}
      }
      ctx.globalAlpha=1;
    },dispose(){}};
  }
  const shader=(kind,src)=>{
    const s=gl.createShader(kind);gl.shaderSource(s,src);gl.compileShader(s);
    if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));
    return s;
  };
  const vs=shader(gl.VERTEX_SHADER,'attribute vec2 p;attribute vec4 c;varying vec4 color;void main(){gl_Position=vec4(p,0.,1.);color=c;}');
  const fs=shader(gl.FRAGMENT_SHADER,'precision mediump float;varying vec4 color;void main(){gl_FragColor=color;}');
  const prog=gl.createProgram();gl.attachShader(prog,vs);gl.attachShader(prog,fs);gl.linkProgram(prog);
  if(!gl.getProgramParameter(prog,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(prog));
  gl.useProgram(prog);
  const buf=gl.createBuffer(), pl=gl.getAttribLocation(prog,'p'),cl=gl.getAttribLocation(prog,'c');
  gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.enableVertexAttribArray(pl);gl.enableVertexAttribArray(cl);
  gl.vertexAttribPointer(pl,2,gl.FLOAT,false,24,0);gl.vertexAttribPointer(cl,4,gl.FLOAT,false,24,8);
  gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);
  gl.clearColor(.875,.921,.91,1);
  return {paint(prims,w,h){
    const vertices=[],sx=2/w,sy=-2/h;
    function vert(x,y,col,a){vertices.push(x*sx-1,y*sy+1,col[0],col[1],col[2],a);}
    function quad(x,y,ww,hh,col,alpha){
      vert(x,y,col,alpha);vert(x+ww,y,col,alpha);vert(x+ww,y+hh,col,alpha);
      vert(x,y,col,alpha);vert(x+ww,y+hh,col,alpha);vert(x,y+hh,col,alpha);
    }
    for(const p of prims){
      let c=p.col, a=p.alpha,points=p.scr;
      if(p.label){
        let [x,y]=points[0];const unit=p.sizePx/5;
        for(const char of p.label){
          const pattern=glyphs[char];if(!pattern){x+=2.5*unit;continue;}
          pattern.forEach((row,j)=>[...row].forEach((val,i)=>{if(val==='1')quad(x+i*unit,y+(j-4)*unit,unit,unit,rgb(c),.92);}));
          x+=(Math.max(...pattern.map(s=>s.length))+1)*unit;
        }
      }else if(p.width){
        const [[x,y],[u,v]]=points,dx=u-x,dy=v-y,len=Math.hypot(dx,dy)||1;
        const ax=-dy/len*p.width/2,ay=dx/len*p.width/2;
        vert(x+ax,y+ay,c,a);vert(x-ax,y-ay,c,a);vert(u-ax,v-ay,c,a);
        vert(x+ax,y+ay,c,a);vert(u-ax,v-ay,c,a);vert(u+ax,v+ay,c,a);
      }else{
        for(let i=1;i<points.length-1;i++){
          vert(points[0][0],points[0][1],c,a);vert(points[i][0],points[i][1],c,a);vert(points[i+1][0],points[i+1][1],c,a);
        }
      }
    }
    gl.viewport(0,0,canvas.width,canvas.height);gl.clear(gl.COLOR_BUFFER_BIT);
    gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.DYNAMIC_DRAW);
    gl.drawArrays(gl.TRIANGLES,0,vertices.length/6);
  },dispose(){gl.deleteBuffer(buf);gl.deleteProgram(prog);gl.deleteShader(fs);gl.deleteShader(vs);}};
}

export function createScene(canvas,callbacks={}){
  let paint=renderer(canvas),contextLost=false;
  let state={items:[],selected:null},yaw=.265,pitch=.205,zoom=1,focus=[0,1.50,0];
  let scene=null,cacheDirty=true,raf=0,dead=false,drag=null,gesture=null,pinch=null,boxInfo=[];
  const pointers=new Map(), events=[];
  canvas.style.touchAction='none';canvas.style.cursor='grab';
  if(!canvas.hasAttribute('tabindex'))canvas.tabIndex=0;
  if(!canvas.hasAttribute('aria-label'))canvas.setAttribute('aria-label','3D 實驗枱。方向鍵旋轉，正負鍵縮放，Enter 操作所選儀器。');
  function basis(){
    const rect=canvas.getBoundingClientRect(),w=rect.width||640,h=rect.height||400;
    const s=Math.min(w/5.85,h/4.48)*zoom,cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
    const right=[cy,0,-sy],up=[-sy*sp,cp,-cy*sp],toward=[sy*cp,sp,cy*cp];
    const project=v=>{
      const d=sub(v,focus);
      return [w*.50+dot(d,right)*s,h*.50-dot(d,up)*s,dot(d,toward)];
    };
    return {rect,w,h,s,project,right,up,toward};
  }
  function draw(){
    raf=0;if(dead||contextLost)return;
    const {w,h,s,project}=basis();const dpr=Math.min(Number(window.devicePixelRatio)||1,state.lowMotion?1.3:2);
    const cw=Math.max(1,Math.round(w*dpr)),ch=Math.max(1,Math.round(h*dpr));
    if(canvas.width!==cw||canvas.height!==ch){canvas.width=cw;canvas.height=ch;}
    if(cacheDirty||!scene){scene=worldGeometry(state,drag,performance.now()/1000);cacheDirty=false;}
    const primitives=[];
    for(const p of scene.prim){
      const pts=p.v.map(project);
      if(pts.every(v=>v[0]<-6)||pts.every(v=>v[0]>w+8)||pts.every(v=>v[1]<-8)||pts.every(v=>v[1]>h+8))continue;
      primitives.push({...p,scr:pts.map(v=>[v[0],v[1]]),depth:pts.reduce((n,v)=>n+v[2],0)/pts.length+(p.width?.002:0)+(p.label?.014:0),sizePx:(p.size||0)*s});
    }
    primitives.sort((a,b)=>a.layer-b.layer||a.depth-b.depth);
    paint.paint(primitives,w,h,dpr);
    boxInfo=scene.targets.map(t=>{
      const y0=t.k==='burette'?1.22:.01,base=project([t.x,y0,t.z]),top=project([t.x,t.h,t.z]);
      return {...t,cx:(base[0]+top[0])/2,l:base[0]-t.w*s*.56-5,r:base[0]+t.w*s*.56+5,b:base[1]+s*t.w*.17+3,t:top[1]-4,depth:base[2]};
    });
    if(state.effect&&!state.lowMotion&&state.running && /bubble|gas/i.test(typeof state.effect==='string'?state.effect:state.effect.type||'')){
      cacheDirty=true;
      if(!raf)raf=requestAnimationFrame(draw);
    }
  }
  function redraw(dirty=false){cacheDirty=cacheDirty||dirty;if(!raf&&!dead)raf=requestAnimationFrame(draw);}
  function update(v){state=v||{items:[]};redraw(true);}
  function camera(action){
    const a=tidy(action); 
    if(['reset','home','orbit','default'].includes(a)){yaw=.265;pitch=.205;zoom=1;focus=[0,1.5,0];}
    else if(['orbitleft','left','rotateleft'].includes(a))yaw-=.18;
    else if(['orbitright','right','rotateright','rotate'].includes(a))yaw+=.18;
    else if(['orbitup','up'].includes(a))pitch=clamp(pitch+.1,.10,1.28);
    else if(['orbitdown','down'].includes(a))pitch=clamp(pitch-.1,.10,1.28);
    else if(['zoomin','in','+'].includes(a))zoom=clamp(zoom*1.18,.62,3.7);
    else if(['zoomout','out','−','-'].includes(a))zoom=clamp(zoom/1.18,.62,3.7);
    else if(['top','overhead','overheadview','plan'].includes(a)){yaw=0;pitch=1.26;focus=[0,.7,0];zoom=1;}
    else if(['front','firstperson','frontview'].includes(a)){yaw=0;pitch=.105;focus=[0,1.55,0];zoom=1;}
    else if(['perspective','thirdperson','side','sideview'].includes(a)){yaw=.78;pitch=.29;focus=[0,1.4,0];zoom=.95;}
    else if(['focus','closeup','objectfocus'].includes(a)){
      const t=scene?.targets.find(t=>t.id===state.selected)||scene?.targets.find(t=>t.k==='flask')||scene?.targets[0];
      if(t){focus=[t.x,t.k==='burette'?2.39:t.h*.55,t.z];zoom=t.h>2?1.46:2.25;}
    }
    redraw();
  }
  function coords(e){const r=canvas.getBoundingClientRect();return [e.clientX-r.left,e.clientY-r.top];}
  function hit(x,y){
    return boxInfo.filter(t=>x>=t.l&&x<=t.r&&y>=t.t&&y<=t.b)
      .sort((a,b)=>(a.k==='stand')-(b.k==='stand')||Math.abs(x-a.cx)/a.w-Math.abs(x-b.cx)/b.w||b.depth-a.depth)[0];
  }
  function on(el,name,cb,opts){el.addEventListener(name,cb,opts);events.push(()=>el.removeEventListener(name,cb,opts));}
  function pdown(e){
    if(e.button!==0&&e.button!==1&&e.button!==2)return;
    const p=coords(e);pointers.set(e.pointerId,p);
    if(canvas.setPointerCapture)canvas.setPointerCapture(e.pointerId);
    if(pointers.size===2){const [a,b]=[...pointers.values()];pinch={dist:Math.hypot(a[0]-b[0],a[1]-b[1]),zoom,mid:[(a[0]+b[0])/2,(a[1]+b[1])/2],focus:[...focus]};gesture=null;drag=null;return;}
    const item=hit(...p);
    gesture={start:p,last:p,item:e.shiftKey||e.button!==0?null:item,pan:e.shiftKey||e.button===1,moved:false,id:e.pointerId};
    canvas.style.cursor='grabbing';
  }
  function pmove(e){
    if(!pointers.has(e.pointerId)){const p=coords(e);canvas.style.cursor=hit(...p)?'pointer':'grab';return;}
    const p=coords(e);pointers.set(e.pointerId,p);
    if(pinch&&pointers.size===2){
      const [a,b]=[...pointers.values()];
      const dist=Math.hypot(a[0]-b[0],a[1]-b[1]);
      zoom=clamp(pinch.zoom*dist/Math.max(1,pinch.dist),.62,3.7);
      const {s,right,up}=basis(),dx=((a[0]+b[0])/2-pinch.mid[0])/s,dy=((a[1]+b[1])/2-pinch.mid[1])/s;
      focus=pinch.focus.map((v,i)=>v-right[i]*dx+up[i]*dy);
      redraw();return;
    }
    if(!gesture||gesture.id!==e.pointerId)return;
    const dx=p[0]-gesture.last[0],dy=p[1]-gesture.last[1];
    const tx=p[0]-gesture.start[0],ty=p[1]-gesture.start[1];
    if(!gesture.moved&&Math.hypot(tx,ty)<5)return;
    gesture.moved=true;gesture.last=p;
    const {s,right,up}=basis();
    if(gesture.item){
      const ox=tx/s,oz=ty/(Math.max(.21,Math.sin(pitch))*s);
      const x=gesture.item.x+Math.cos(yaw)*ox+Math.sin(yaw)*oz;
      const z=gesture.item.z-Math.sin(yaw)*ox+Math.cos(yaw)*oz;
      drag={id:gesture.item.id,x:clamp(x,-limits.x,limits.x),z:clamp(z,-limits.z,limits.z)};redraw(true);
    }else if(gesture.pan){
      focus=focus.map((v,i)=>v-right[i]*dx/s+up[i]*dy/s);redraw();
    }else{yaw-=dx*.010;pitch=clamp(pitch+dy*.008,.1,1.28);redraw();}
  }
  function pend(e){
    if(!pointers.has(e.pointerId))return;
    pointers.delete(e.pointerId);if(pinch){if(pointers.size<2)pinch=null;gesture=null;return;}
    if(!gesture)return;
    if(e.type!=='pointercancel'){
      if(drag){
        const {id}=drag;let x=Math.round(drag.x*20)/20,z=Math.round(drag.z*20)/20;
        const mover=gesture.item;
        for(const t of scene.targets){
          if(t.id===id)continue;
          const distance=Math.hypot(x-t.x,z-t.z);
          if([mover.k,t.k].includes('burette')&&[mover.k,t.k].some(k=>k==='flask'||k==='beaker')&&distance<.32){x=t.x;z=t.z;continue;}
          if(['burette','pipette','probe','electrode'].includes(mover.k)||['burette','pipette','probe','electrode'].includes(t.k))continue;
          const min=(mover.w+t.w)*.39;
          if(distance<min){const angle=distance>.001?Math.atan2(z-t.z,x-t.x):0;x=t.x+Math.cos(angle)*min;z=t.z+Math.sin(angle)*min;}
        }
        callbacks.onSelect?.(id);callbacks.onMove?.(id,clamp(x,-limits.x,limits.x),clamp(z,-limits.z,limits.z));
      }else if(!gesture.moved&&gesture.item){callbacks.onSelect?.(gesture.item.id);}
    }
    gesture=null;drag=null;canvas.style.cursor='grab';redraw(true);
  }
  on(canvas,'webglcontextlost',e=>{e.preventDefault();contextLost=true;});
  on(canvas,'webglcontextrestored',()=>{paint=renderer(canvas);contextLost=false;redraw(true);});
  on(canvas,'pointerdown',pdown);on(canvas,'pointermove',pmove);on(canvas,'pointerup',pend);on(canvas,'pointercancel',pend);
  on(canvas,'dblclick',e=>{const t=hit(...coords(e));if(t){callbacks.onSelect?.(t.id);callbacks.onActivate?.(t.id);}});
  on(canvas,'contextmenu',e=>e.preventDefault());
  on(canvas,'wheel',e=>{e.preventDefault();zoom=clamp(zoom*Math.exp(-e.deltaY*.0014),.62,3.7);redraw();},{passive:false});
  on(canvas,'keydown',e=>{
    const map={ArrowLeft:'left',ArrowRight:'right',ArrowUp:'up',ArrowDown:'down','+':'zoomIn','=':'zoomIn','-':'zoomOut','0':'reset',Home:'reset',f:'focus',F:'focus'};
    if(map[e.key]){e.preventDefault();camera(map[e.key]);}
    else if(e.key==='Enter'&&state.selected){e.preventDefault();callbacks.onActivate?.(state.selected);}
  });
  const observer=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>redraw()):null;
  observer?.observe(canvas);on(window,'resize',()=>redraw());
  redraw(true);
  return {update,camera,destroy(){dead=true;observer?.disconnect();events.forEach(fn=>fn());cancelAnimationFrame(raf);paint.dispose();}};
}
