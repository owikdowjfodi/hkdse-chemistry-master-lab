import React from 'react';
import {createRoot} from 'react-dom/client';
type Action = {id:string,label:string,en:string};
type Props = {actions:Action[], english:boolean, onAction:(id:string)=>void};
export function attachControls(el:HTMLElement){const root=createRoot(el);return (props:Props)=>root.render(<div className="actgroup">{props.actions.map(a=><button key={a.id} type="button" onClick={()=>props.onAction(a.id)}>{props.english?a.en:a.label}</button>)}</div>)}
