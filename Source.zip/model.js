// All volumes are mL, amounts mmol, time seconds, temperatures °C unless stated.
// Models use controlled classroom assumptions. Numeric values are independent of rendering.
const F = 96485.33212, R = 8.314462618, MW_CU = 63.546;
const fixed = (n, dp = 2) => Number.isFinite(n) ? n.toFixed(dp) : '—';
const clamp = (n, a, b) => Math.min(b, Math.max(a,n));
const rounded = n => Math.round(n*1e10)/1e10;
const metric = (label, en, value, unit = '') => ({label,en,value,unit});
const range = (id,label,en,min,max,step,value,unit='') => ({id,label,en,type:'range',min,max,step,value,unit});
const select = (id,label,en,value,...items) => ({id,label,en,type:'select',value,options:items.map(([value,label,en])=>({value,label,en}))});
const action = (id,label,en) => ({id,label,en});
const start = action('start','開始計時','Start timer'), stop = action('stop','暫停','Pause');
export const protocols = {
 titration:{controls:[
   range('acid','鹽酸濃度','HCl concentration',.05,.15,.005,.1,'mol/L'),
   range('base','氫氧化鈉濃度','NaOH concentration',.08,.2,.005,.1,'mol/L'),
   select('indicator','指示劑','Indicator','phenol',['phenol','酚酞','Phenolphthalein'],['bromo','溴百里酚藍','Bromothymol blue'],['none','無','None'])],
  actions:[action('drop','逐滴加入 0.05 mL','One drop · 0.05 mL'),action('dose','加入 1.00 mL','Deliver 1.00 mL'),action('quick','加入 5.00 mL','Deliver 5.00 mL'),action('swirl','旋動錐形瓶','Swirl flask'),action('refill','補滿滴定管','Refill burette'),action('aliquot','移取新樣本','Pipette fresh aliquot'),action('wet','使用有殘水的滴定管','Use water-wet burette')]},
 analysis:{controls:[select('reagent','鑑定試劑','Test reagent','oh',['oh','氫氧化鈉溶液','Sodium hydroxide'],['nh3','氨水','Aqueous ammonia'])],
  actions:[action('sample','取新分樣','Take fresh aliquot'),action('add','少量試劑','Add a few drops'),action('excess','加入過量試劑','Add excess reagent'),action('unknown','下一個未知樣本','Next unknown')]},
 electrolysis:{controls:[range('current','電流','Current',0,2,.05,.5,'A'),select('anode','陽極材料','Anode','Cu',['Cu','銅','Copper'],['C','惰性石墨','Inert graphite'])],
  actions:[action('wire','接駁／斷開電路','Connect / open circuit'),start,stop,action('weigh','稱量陰極','Weigh cathode')]},
 rate:{controls:[range('acid','鹽酸濃度','HCl concentration',.1,1,.05,.5,'mol/L'),range('temp','反應溫度','Reaction temperature',15,40,1,25,'°C'),select('surface','碳酸鈣形態','Marble surface','chip',['chip','顆粒','Chips'],['fine','細粒','Fine grains'])],
  actions:[action('connect','接駁／移開集氣筒','Connect / remove syringe'),start,stop,action('read','讀取氣筒','Read gas syringe')]},
 heat:{controls:[range('volume','鹽酸體積','HCl volume',10,50,5,25,'mL'),range('baseVol','氫氧化鈉體積','NaOH volume',10,50,5,25,'mL'),range('ambient','室溫及初溫','Room and start temperature',15,35,1,25,'°C'),range('loss','散熱係數','Thermal conductance',0,.5,.01,.15,'W/K')],
  actions:[action('mix','混合兩溶液','Mix solutions'),start,stop,action('read','讀取溫度探針','Read probe')]},
 equilibrium:{controls:[range('temp','系統溫度','System temperature',10,50,1,25,'°C')],
  actions:[action('dose','加入 1 mmol A','Add 1 mmol A'),action('compress','壓縮體積','Compress volume'),action('expand','增加體積','Expand volume'),start,stop]}
};

export function initModel(key='titration'){
 if(!Object.hasOwn(protocols,key)) throw Error('Unsupported experiment');
 const initial={
  titration:{delivered:0,burette:50,stockFactor:1,baseMmol:0,mixed:true,overshot:false,aliquot:25},
  analysis:{unknownIndex:0,aliquot:1,stage:0,used:null,evidence:[],tests:0},
  electrolysis:{wired:false,charge:0,deposited:0,oxygen:0,cu:5,anodeLoss:0,anodeRemaining:5},
  rate:{connected:false,extent:0,collected:0,lost:0,started:false},
  heat:{mixed:false,T:25,probe:25,peak:25},
  equilibrium:{atom:4,b:0,V:1}
 }[key];
 return {key,params:Object.fromEntries(protocols[key].controls.map(c=>[c.id,c.value])),running:false,time:0,lastEvent:null,message:'',messageEn:'',...initial};
}
function tell(m,zh,en){m.message=zh;m.messageEn=en;return m;}
function incident(m,type,title,en,detail,detailEn){
 m.lastEvent={type,title,en,detail,detailEn,time:m.time};
 return tell(m,detail,detailEn);
}
function setParam(m,change){
 if(!change || typeof change!=='object')return m;
 let {id,value}=change;
 const def=protocols[m.key].controls.find(c=>c.id===id);
 if(!def)return m;
 if((m.key==='titration' && m.delivered>0 && ['acid','base'].includes(id)) ||
    (m.key==='rate' && m.started && id==='acid') ||
    (m.key==='heat' && m.mixed && ['volume','baseVol','ambient'].includes(id)) ||
    (m.key==='electrolysis' && m.running && id==='anode')){
    return tell(m,'本次操作已開始。請先重設或取新樣本才更改這項條件。','Reset the experiment or prepare a new aliquot to change this starting condition.');
 }
 if(def.type==='select'){
   if(!def.options.some(o=>o.value===value))return m;
 }else{
   if(value==null||value===''||!Number.isFinite(Number(value)))return m;
   value=rounded(clamp(def.min+Math.round((Number(value)-def.min)/def.step)*def.step,def.min,def.max));
 }
 m.params[id]=value;
 if(m.key==='heat' && id==='ambient')m.T=m.probe=m.peak=value;
 return m;
}
// Water autoionisation prevents numerical singularities around equivalence.
export function strongPH(netAcidM){
 const root=Math.hypot(netAcidM,2e-7);
 return netAcidM>=0?-Math.log10((netAcidM+root)/2):14+Math.log10((-netAcidM+root)/2);
}
function titrate(m,a){
 if(a==='swirl'){m.mixed=true;return tell(m,'錐形瓶已混合均勻；可記錄探針讀數。','The flask is mixed. Record the probe reading.');}
 if(a==='refill'){m.burette=50;m.stockFactor=1;return tell(m,'滴定管已用標準溶液潤洗及補滿；累計用量繼續計算。','Burette rinsed and refilled. Cumulative delivered volume is retained.');}
 if(a==='aliquot'){m.delivered=0;m.baseMmol=0;m.overshot=false;m.mixed=true;return tell(m,'已換上盛有 25.00 mL 鹽酸的錐形瓶。','Replaced flask with a fresh 25.00 mL acid aliquot.');}
 if(a==='wet'){
   if(m.delivered>0)return tell(m,'先取新分樣，才可重做潤洗誤差試驗。','Take a fresh aliquot to repeat the rinse-error trial.');
   m.stockFactor=.98;m.burette=50;
   return incident(m,'contamination','殘水稀釋滴定劑','Diluted titrant','教學條件為 1.00 mL 殘水與 49.00 mL 標準溶液完全混合。','The model mixes 1.00 mL residual water with 49.00 mL titrant.');
 }
 const req={drop:.05,dose:1,quick:5}[a];
 if(!req)return m;
 if(m.burette<=0)return tell(m,'滴定管已空；補滿後才可繼續。','The burette is empty. Refill it to continue.');
 const capacityLeft=100-m.aliquot-m.delivered;
 if(capacityLeft<=0)return incident(m,'capacity','錐形瓶已滿','Flask at capacity','100 mL 錐形瓶已滿；請移取新樣本。','The 100 mL flask is full. Prepare a fresh aliquot.');
 const v=Math.min(req,m.burette,capacityLeft);m.delivered=rounded(m.delivered+v);m.burette=rounded(m.burette-v);m.baseMmol=rounded(m.baseMmol+v*m.params.base*m.stockFactor);m.mixed=false;
 if(m.baseMmol>m.aliquot*m.params.acid+1e-10 && !m.overshot){
  m.overshot=true;
  return incident(m,'overshoot','超過化學計量當量點','Past stoichiometric equivalence','鹼的物質的量已超過初始酸量。請比較當量點與指示劑終點。','Moles of added base exceed initial acid. Compare the equivalence point with the indicator endpoint.');
 }
 return tell(m,'已加入 '+fixed(v)+' mL。旋瓶後可把平衡預測與均勻樣品對照。','Delivered '+fixed(v)+' mL. Swirl to obtain a homogeneous flask.');
}
// Identifications are conditional on this declared three-ion candidate set.
const IONS=['Zn²⁺','Mg²⁺','Cu²⁺'];
const tests={
 'Zn²⁺':{oh:['white','clear'],nh3:['white','clear']},
 'Mg²⁺':{oh:['white','white'],nh3:['white','white']},
 'Cu²⁺':{oh:['blue','blue'],nh3:['blue','deep']}
};
const appearances={
 white:['白色沉澱','White precipitate','#eee8d8'],
 clear:['沉澱溶解，無色溶液','Precipitate dissolves to a colourless solution','#bfdedf'],
 blue:['淺藍色沉澱','Pale blue precipitate','#7cbbe4'],
 deep:['沉澱溶解，深藍色溶液','Precipitate dissolves to a deep blue solution','#2754bc']
};
function analyse(m,a){
 if(a==='unknown'){const fresh=initModel('analysis');fresh.unknownIndex=(m.unknownIndex+1)%IONS.length;return fresh;}
 if(a==='sample'){m.aliquot++;m.stage=0;m.used=null;return tell(m,'已取同一未知溶液的新分樣；保留過往證據。','Fresh aliquot of the same unknown. Earlier evidence retained.');}
 if(!['add','excess'].includes(a))return m;
 if(m.used && m.used!==m.params.reagent)return incident(m,'contamination','試劑混用','Mixed reagents','不同試劑須使用新分樣；此混合的觀察不獲模型支援。','Use a fresh aliquot for the other reagent. Mixed-reagent observations are unsupported.');
 if(a==='excess' && m.stage===0)return tell(m,'先加少量試劑並記錄初步觀察。','Add a few drops and record the initial observation first.');
 if(m.stage===2 || (m.stage===1&&a==='add'))return tell(m,'這一分樣已完成此步；可加入過量試劑或取新分樣。','This step was already recorded. Add excess reagent or take a fresh aliquot.');
 m.used=m.params.reagent;m.stage=a==='excess'?2:1;m.tests++;
 const appearance=tests[IONS[m.unknownIndex]][m.used][m.stage-1];
 m.evidence.push({reagent:m.used,stage:m.stage,appearance});
 return tell(m,appearances[appearance][0],appearances[appearance][1]);
}
function electro(m,a,dt){
 if(a==='wire'){m.wired=!m.wired;if(!m.wired)m.running=false;return tell(m,m.wired?'電路已接通。':'電路已斷開。',m.wired?'Circuit connected.':'Circuit opened.');}
 if(a==='weigh')return tell(m,'已乾燥陰極；相對初次稱量增重 '+fixed(m.deposited,4)+' g。','Dry cathode gain: '+fixed(m.deposited,4)+' g.');
 if(a==='start'&&!m.wired)return incident(m,'openCircuit','電路未接通','Open circuit','電源與電極未形成閉合電路；沒有銅沉積。','The circuit is open; no copper is deposited.');
 if(a==='start'){m.running=true;return m;}
 if(a!=='tick'||!m.running)return m;
 const p=m.params;
 const maxCu=p.anode==='Cu'&&m.cu>1e-12?m.anodeRemaining:m.cu;
 if(maxCu<=1e-12){m.running=false;return tell(m,'已達支援的銅電極／離子供應範圍。','Copper supply exhausted within this model.');}
 const requested=p.current*dt*1000/(2*F),n=Math.min(requested,maxCu);
 m.time+=requested>0?dt*n/requested:dt;
 m.charge+=n*2*F/1000;m.deposited+=n*MW_CU/1000;
 if(p.anode==='C'){m.cu=Math.max(0,m.cu-n);m.oxygen+=n/2;}
 else{m.anodeRemaining=Math.max(0,m.anodeRemaining-n);m.anodeLoss+=n*MW_CU/1000;}
 if(n>=maxCu)m.running=false;
 return m;
}
// Illustrative rate constants, not fitted CaCO3 kinetics. Gas is compared at fixed conditions.
function rate(m,a,dt){
 if(a==='connect'){m.connected=!m.connected;return tell(m,m.connected?'集氣筒已接駁。':'集氣筒已移開。',m.connected?'Gas syringe connected.':'Gas syringe removed.');}
 if(a==='read')return tell(m,'已收集 '+fixed(m.collected)+' mL 乾燥氣體（折算至 25 °C、1 atm）。','Collected '+fixed(m.collected)+' mL dry gas at 25 °C, 1 atm.');
 const max=Math.min(2,10*m.params.acid/2);
 if(a==='start'){
   if(max-m.extent<1e-10)return tell(m,'限量反應物已耗盡。','Limiting reagent exhausted.');
   m.running=m.started=true;
   if(!m.connected)return incident(m,'leak','未連接集氣筒','Syringe disconnected','氣體會逸走，令收集值偏低。','Gas escapes, reducing the measured volume.');
   return m;
 }
 if(a!=='tick'||!m.running)return m;
 const k=.035*(m.params.acid/.5)*Math.exp(30000/R*(1/298.15-1/(273.15+m.params.temp)))*(m.params.surface==='fine'?2:1);
 let dn=(max-m.extent)*(-Math.expm1(-k*dt));
 if(max-m.extent-dn<1e-8){dn=max-m.extent;m.running=false;}
 m.extent+=dn;m.time+=dt;
 const gas=dn*R*298.15/101.325;
 if(m.connected)m.collected+=gas;else m.lost+=gas;
 return m;
}
function heat(m,a,dt){
 const {volume,baseVol,ambient,loss}=m.params;
 if(a==='mix'){
  if(m.mixed)return tell(m,'兩份試劑已混合；重設以開始新試驗。','Already mixed. Reset for a new trial.');
  const q=Math.min(volume,baseVol)*57.3; // 1 M solutions, 57.3 J per mmol
  m.T=ambient+q/((volume+baseVol)*4.18+15);m.peak=m.T;m.mixed=m.running=true;
  return tell(m,'已混合，溫度探針正追趕液體溫度。','Solutions mixed. The probe responds with a time lag.');
 }
 if(a==='start'){if(m.mixed)m.running=true;else tell(m,'請先混合兩份溶液。','Mix the two solutions first.');return m;}
 if(a==='read')return tell(m,'探針讀數 '+fixed(m.probe)+' °C。','Probe reading '+fixed(m.probe)+' °C.');
 if(a!=='tick'||!m.running)return m;
 const k=loss/((volume+baseVol)*4.18+15),h=1/3,excess=m.T-ambient;
 // Exact coupled Newton cooling and first-order probe response.
 const ek=Math.exp(-k*dt),eh=Math.exp(-h*dt);
 m.probe=ambient+(m.probe-ambient)*eh+h*excess*(ek-eh)/(h-k);
 m.T=ambient+excess*ek;m.time+=dt;
 return m;
}
function eqConsts(T){
 // Generic, explicitly illustrative 2A ⇌ B model; amounts in mol and L.
 const t=T+273.15,K=500*Math.exp(18000/R*(1/t-1/298.15));
 const kr=.06*Math.exp(12000/R*(1/298.15-1/t));return {K,kr,kf:kr*K};
}
function balance(m){
 const {K}=eqConsts(m.params.temp),total=m.atom/1000/m.V;
 const A=2*total/(1+Math.sqrt(1+8*K*total));
 return K*A*A*m.V*1000;
}
function equilibrium(m,a,dt){
 if(a==='dose'){m.atom+=1;return tell(m,'已加入 1 mmol A；總物料及反應商已更新。','Added 1 mmol A. Total inventory and Q updated.');}
 if(a==='compress'||a==='expand'){m.V=clamp(m.V*(a==='compress'?.8:1.25),.25,4);return tell(m,'容器體積 '+fixed(m.V,3)+' L。','Vessel volume '+fixed(m.V,3)+' L.');}
 if(a==='start'){m.running=true;return m;}
 if(a!=='tick'||!m.running)return m;
 const {kf,kr}=eqConsts(m.params.temp),N=m.atom/1000,V=m.V;
 const b1=balance(m)/1000,b2=(N/2)**2/b1;
 const r=(m.b/1000-b1)/(m.b/1000-b2)*Math.exp(-4*kf*(b2-b1)*dt/V);
 m.b=clamp(1000*(b1-r*b2)/(1-r),0,m.atom/2);m.time+=dt;return m;
}
const runners={titration:titrate,analysis:analyse,electrolysis:electro,rate,heat,equilibrium};
export function applyModel(model,act,value){
 if(!Object.hasOwn(protocols,model.key))throw Error('Unsupported experiment');
 if(act==='reset')return initModel(model.key);
 const m={...model,params:{...model.params},lastEvent:null};
 if(m.evidence)m.evidence=m.evidence.slice();
 if(act==='set')return setParam(m,value);
 if(act==='stop'){m.running=false;return m;}
 if(act==='tick' && (!m.running||!Number.isFinite(value)||value<=0))return m;
 return runners[m.key](m,act,value);
}
function reading({label,en,value,unit,x,xLabel,xEn,yLabel=label,yEn=en,metrics,observation,observationEn,color='#b7dfe0',fill=.35,...extra}){
 return {label,en,labelEn:en,value,unit,x,y:value,xLabel,xEn,xLabelEn:xEn,yLabel,yEn,yLabelEn:yEn,metrics,observation,observationEn,color,fill,...extra};
}
const amount = (label,en,n,unit='mmol',dp=3)=>metric(label,en,fixed(n,dp),unit);
function readTitration(m){
 const acidMmol=m.params.acid*m.aliquot,volume=m.aliquot+m.delivered;
 const net=(acidMmol-m.baseMmol)/volume,pH=strongPH(net);
 let tint='colourless',zh='無色',color='#c1e3e4';
 if(m.params.indicator==='phenol'&&pH>=8.2){
   const s=clamp((pH-8.2)/1.8,0,1);
   color='rgb('+Math.round(235+13*s)+','+Math.round(204-71*s)+','+Math.round(217-40*s)+')';
   tint=s>.7?'pink':'pale pink';zh=s>.7?'粉紅':'淡粉紅';
 }else if(m.params.indicator==='bromo'){
   [tint,zh,color]=pH<6?['yellow','黃色','#d9c866']:pH>7.6?['blue','藍色','#6199d2']:['green','綠色','#71b49a'];
 }
 const scope=m.mixed?'已混合均勻。':'尚待旋瓶；顯示完全混合後的預測。';
 const enScope=m.mixed?'Flask is uniformly mixed.':'Swirl the flask; displayed pH assumes complete mixing.';
 return reading({label:'酸鹼值',en:'pH',value:pH,unit:'pH',x:m.delivered,xLabel:'已加滴定劑 / mL',xEn:'Titrant delivered / mL',yLabel:'pH',yEn:'pH',
  metrics:[amount('累計加入','Delivered',m.delivered,'mL',2),amount('滴定管刻度','Burette scale',50-m.burette,'mL',2),amount('樣本體積','Acid aliquot',m.aliquot,'mL',2),amount('過量 H⁺','Excess H⁺',Math.max(0,acidMmol-m.baseMmol)),amount('過量 OH⁻','Excess OH⁻',Math.max(0,m.baseMmol-acidMmol))],
  observation:'指示劑觀察：'+zh+'。'+scope,observationEn:'Indicator: '+tint+'. '+enScope,color,fill:clamp(volume/100,0,1),buretteFill:m.burette/50});
}
function readAnalysis(m){
 const candidates=IONS.filter(ion=>m.evidence.every(e=>tests[ion][e.reagent][e.stage-1]===e.appearance));
 const look=m.stage?appearances[tests[IONS[m.unknownIndex]][m.used][m.stage-1]]:IONS[m.unknownIndex]==='Cu²⁺'?['未加試劑，樣品呈藍色','Untested blue sample','#84c1e3']:['未加試劑，樣品無色','Untested colourless sample','#c1e3e4'];
 return reading({label:'符合試劑測試的離子',en:'Candidates matching reagent tests',value:candidates.length,unit:'',x:m.tests,xLabel:'測試次數',xEn:'Reagent observations',
  metrics:[metric('分樣編號','Aliquot',m.aliquot),metric('測試次數','Tests',m.tests),metric('可能離子','Candidates',candidates.join(' / '))],
  observation:look[0]+'。候選範圍：Zn²⁺、Mg²⁺、Cu²⁺。',observationEn:look[1]+'. Candidate set: Zn²⁺, Mg²⁺ and Cu²⁺.',color:look[2],fill:.34+m.stage*.08,precipitate:m.stage>0&&['white','blue'].includes(tests[IONS[m.unknownIndex]][m.used][m.stage-1]),candidates});
}
function readElectro(m){
 return reading({label:'陰極增重',en:'Cathode gain',value:m.deposited*1000,unit:'mg',x:m.time,xLabel:'時間 / s',xEn:'Time / s',yLabel:'銅沉積 / mg',yEn:'Copper deposited / mg',
  metrics:[amount('總電量','Charge',m.charge,'C',2),amount('電流','Current',m.running&&m.wired?m.params.current:0,'A',2),amount('陽極銅減重','Anode copper lost',m.anodeLoss*1000,'mg',3),amount('剩餘 Cu²⁺','Cu²⁺ in solution',m.cu),amount('陽極 O₂','Anode O₂',m.oxygen)],
  observation:m.params.anode==='Cu'?'銅陽極溶解；閉合電路時陰極析銅（假設電流效率 100%）。':'石墨陽極產氧，陰極析銅；限定硫酸銅溶液及支援的電流效率。',
  observationEn:m.params.anode==='Cu'?'Copper transfers from anode to cathode in a closed circuit; 100% current efficiency assumed.':'For this copper sulfate solution, graphite anode produces oxygen and cathode deposits copper at assumed 100% efficiency.',
  color:'#7abddf',fill:.55,deposit:m.deposited,bubbles:m.running&&m.params.anode==='C'&&m.params.current>0});
}
function readRate(m){
 return reading({label:'收集氣體體積',en:'Collected gas',value:m.collected,unit:'mL',x:m.time,xLabel:'時間 / s',xEn:'Time / s',yLabel:'CO₂ / mL',yEn:'CO₂ / mL',
  metrics:[amount('反應進度','Reaction extent',m.extent),amount('未收集 CO₂','Escaped CO₂',m.lost,'mL',2),amount('剩餘 CaCO₃','CaCO₃ left',2-m.extent),amount('剩餘 HCl','HCl left',Math.max(0,m.params.acid*10-2*m.extent))],
  observation:'碳酸鈣與 10 mL 鹽酸反應。速率常數屬教學假設；乾氣體積折算至 25 °C、1 atm。',observationEn:'Marble reacts with 10 mL HCl. Illustrative kinetics; dry gas volumes are normalised to 25 °C, 1 atm.',fill:.35,bubbles:m.running});
}
function readHeat(m){
 return reading({label:'探針溫度',en:'Probe temperature',value:m.probe,unit:'°C',x:m.time,xLabel:'時間 / s',xEn:'Time / s',yLabel:'探針溫度 / °C',yEn:'Probe temperature / °C',
  metrics:[amount('液體溫度','Liquid temperature',m.T,'°C',2),amount('初始溫度','Initial temperature',m.params.ambient,'°C',2),amount('反應放熱','Heat released',m.mixed?Math.min(m.params.volume,m.params.baseVol)*57.3:0,'J',1),amount('量熱器熱容量','Cup heat capacity',15,'J/K',1)],
  observation:'兩份溶液均為 1.00 M。採用每摩爾中和放熱 57.3 kJ 的近似值；探針延遲時間常數 3 秒。',observationEn:'Both solutions are 1.00 M. Model neutralisation releases approximately 57.3 kJ/mol. Probe time constant: 3 s.',fill:(m.mixed?m.params.baseVol+m.params.volume:m.params.volume)/125});
}
function readEquilibrium(m){
 const {K,kf,kr}=eqConsts(m.params.temp),A=(m.atom-2*m.b)/1000/m.V,B=m.b/1000/m.V;
 return reading({label:'B 的物質的量',en:'Amount of B',value:m.b,unit:'mmol',x:m.time,xLabel:'時間 / s',xEn:'Time / s',yLabel:'B / mmol',yEn:'B / mmol',
  metrics:[amount('A','A',A*1000,'mmol/L'),amount('B','B',B*1000,'mmol/L'),amount('體積','Volume',m.V,'L',2),amount('Kc','Kc',K,'L/mol',2),amount('Qc','Qc',A>0?B/A**2:Infinity,'L/mol',2),amount('正向速率','Forward rate',kf*A*A*1000,'mmol/L/s',4),amount('逆向速率','Reverse rate',kr*B*1000,'mmol/L/s',4),amount('B 平衡量','B at equilibrium',balance(m))],
  observation:'假想基元反應 2A(g) ⇌ B(g)。速率常數和反應焓是教學假設；不預測真實氣體的顏色或反應時間。',observationEn:'Hypothetical elementary reaction 2A(g) ⇌ B(g). Rates and enthalpy are illustrative; no real-gas colour or time is predicted.',color:'#dae5e4',fill:0});
}
const readers={titration:readTitration,analysis:readAnalysis,electrolysis:readElectro,rate:readRate,heat:readHeat,equilibrium:readEquilibrium};
export const readModel=m=>readers[m.key](m);
