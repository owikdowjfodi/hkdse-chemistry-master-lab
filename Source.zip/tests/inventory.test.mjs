import test from 'node:test';
import assert from 'node:assert/strict';
import {chemicals,equipment,emptySolution,readSolution,addStock,pour} from '../inventory.js';

const close=(a,b,eps=1e-10)=>assert.ok(Math.abs(a-b)<eps,`${a} versus ${b}`);
const stock=(id,ml)=>addStock(emptySolution(),id,ml,250).solution;

test('catalog ID uniqueness, all four supported stocks and mono-/polyatomic formula mass',()=>{
  for(const records of [chemicals,equipment]){
    assert.equal(new Set(records.map(r=>r.id)).size,records.length);
    assert.ok(records.every(r=>r.zh && r.en && r.provenance));
  }
  assert.deepEqual(chemicals.filter(r=>r.usable).map(r=>r.id).sort(),['hcl','nacl','naoh','water']);
  assert.equal(chemicals.find(r=>r.id==='water').molarMass,18.02);
  assert.equal(chemicals.find(r=>r.id==='calciumHydroxide').molarMass,74.09);
  assert.equal(chemicals.find(r=>r.id==='leadNitrate').molarMass,331.21);
  assert.equal(chemicals.find(r=>r.id==='pvc').molarMass,null);
});
test('acid, base and neutral references at 25 °C',()=>{
  close(readSolution(stock('hcl',25)).pH,1);
  close(readSolution(stock('naoh',25)).pH,13);
  for (const id of ['water','nacl']) close(readSolution(stock(id,50)).pH,7);
  assert.equal(readSolution(emptySolution()).pH,null);
  const mixed=addStock(stock('hcl',25),'naoh',25,100).solution;
  close(readSolution(mixed).pH,7);close(readSolution(mixed).sodium,0.0025);
  close(readSolution(mixed).chloride,0.0025);assert.ok(readSolution(addStock(mixed,'naoh',0.05,100).solution).pH>7);
});
test('dilution preserves analytical moles, goes toward pH 7 on both sides',()=>{
  for(const [id,pH] of [['hcl',2],['naoh',12]]){
    const initial=stock(id,10),s=addStock(initial,'water',90,200).solution;
    close(s[id],initial[id]);close(readSolution(s).pH,pH,1e-8);
    const nearNeutral={...emptySolution(),volume:100,[id]:1e-16};
    assert.ok(Math.abs(readSolution(nearNeutral).pH-7)<1e-6);
  }
});
test('transfers limited by source and remaining room; overflow mass stays accountable',()=>{
  const source=stock('hcl',12),dest=stock('naoh',5);
  const p=pour(source,dest,20,11);
  assert.equal(p.source.volume,0);assert.equal(p.transferred,12);assert.equal(p.overflow,6);assert.equal(p.accepted,6);
  assert.equal(p.destination.volume,11);assert.equal(p.spill.volume,6);
  for(const k of ['hcl','naoh','nacl']) close(source[k]+dest[k],p.source[k]+p.destination[k]+p.spill[k]);
  assert.equal(source.volume,12);assert.equal(dest.volume,5);
});
test('unknown models, invalid requests and self-transfer cannot yield invented samples',()=>{
  const s=stock('water',2);
  for(const id of ['peroxide','chlorine','__proto__','constructor','']) assert.throws(()=>addStock(s,id,5,20),RangeError);
  for(const value of [Infinity,NaN,-1,'10']) assert.throws(()=>pour(s,emptySolution(),value,10),RangeError);
  assert.throws(()=>pour(s,s,1,20),RangeError);
  assert.throws(()=>readSolution({...emptySolution(),hcl:1}),RangeError);
});
test('repeated partial transfers preserve total matter across free vessels and spills',()=>{
  let seed=42;
  const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
  let a=addStock(stock('naoh',60),'nacl',25,100).solution,b=stock('hcl',45);
  const totals={},lost=emptySolution();
  for(const k of Object.keys(lost)) totals[k]=a[k]+b[k];
  for(let i=0;i<200;i++){
    const p=pour(a,b,random()*35,92);
    for(const k of Object.keys(lost)) lost[k]+=p.spill[k];
    a=p.destination;b=p.source;
  }
  for(const k of Object.keys(lost)) close(totals[k],a[k]+b[k]+lost[k],1e-8);
});
