import assert from 'node:assert/strict';
import {test} from 'node:test';
import {applyModel as act,initModel as init,readModel as read,protocols,strongPH} from '../model.js';

const near=(a,b,tol=1e-8)=>assert.ok(Math.abs(a-b)<=tol, `${a} differs from ${b}`);
const set=(m,id,value)=>act(m,'set',{id,value});
const dose=(m,n)=>{for(let i=0;i<n;i++)m=act(m,'quick');return m;};
test('all six protocols initialise with finite data and serialisable state',()=>{
 for(const key of Object.keys(protocols)){
  const m=init(key);const d=read(m);
  assert.ok(Number.isFinite(d.value));assert.ok(Number.isFinite(d.x));assert.ok(d.metrics.length>=3);assert.ok(d.observationEn);
  assert.deepEqual(read(JSON.parse(JSON.stringify(m))),d);
 }
});
test('strict input validation and state immutability',()=>{
 const m=init('titration');near(set(m,'base',Infinity).params.base,.1);near(set(m,'base',100).params.base,.2);
 near(set(m,'base',.135).params.base,.135);assert.equal(m.params.base,.1);
 assert.deepEqual(act(init('heat'),'tick',NaN),init('heat'));
 assert.throws(()=>init('imaginary'));
 assert.equal(set(init('analysis'),'reagent','invalid').params.reagent,'oh');
});
test('strong acid/base covers acidic, exact neutral and excess base',()=>{
 near(strongPH(.1),1,1e-10);near(strongPH(0),7);near(strongPH(-.01),12,1e-9);
 for(const c of [1e-15,1e-9,1e-3,1])near(strongPH(c)+strongPH(-c),14);
});
test('25.00 mL of each 0.100 M solution reaches exact equivalence',()=>{
 const m=dose(init('titration'),5);near(read(m).value,7);assert.equal(m.burette,25);assert.ok(!m.overshot);
 const next=act(m,'drop');assert.ok(read(next).value>7);assert.equal(next.lastEvent.type,'overshoot');
 assert.equal(m.delivered,25);near(next.delivered+next.burette,50);
 assert.ok(act(next,'swirl').mixed);assert.equal(set(next,'acid',.15).params.acid,.1);
});
test('empty burette, refilling, wet glass and new aliquot retain mass balance',()=>{
 const m=dose(init('titration'),15);assert.equal(m.delivered,50);assert.equal(m.burette,0);
 const next=act(act(m,'refill'),'dose');assert.equal(next.burette,49);assert.equal(next.baseMmol,5.1);
 const wet=dose(act(init('titration'),'wet'),5);assert.ok(read(wet).value<7);
 const fresh=act(wet,'aliquot');assert.equal(fresh.burette,25);assert.equal(fresh.baseMmol,0);
});
test('qualitative analysis preserves ambiguity and combines observations across clean aliquots',()=>{
 let m=init('analysis');m=act(m,'add');assert.deepEqual(read(m).candidates,['Zn²⁺','Mg²⁺']);
 const changed=set(m,'reagent','nh3');const mixed=act(changed,'excess');assert.equal(mixed.lastEvent.type,'contamination');assert.equal(mixed.tests,1);
 m=act(changed,'sample');m=act(act(m,'add'),'excess');assert.deepEqual(read(m).candidates,['Zn²⁺']);assert.equal(m.tests,3);
 const mg=act(act(act(m,'unknown'),'add'),'excess');assert.deepEqual(read(mg).candidates,['Mg²⁺']);
 const cu=act(act(mg,'unknown'),'add');assert.deepEqual(read(cu).candidates,['Cu²⁺']);
 assert.equal(read(init('analysis')).candidates.length,3);
});
test('electrolysis obeys Faraday and circuit constraints',()=>{
 let m=init('electrolysis');assert.equal(act(m,'start').lastEvent.type,'openCircuit');
 m=act(act(m,'wire'),'start');const ten=act(m,'tick',10),twenty=act(m,'tick',20);
 near(twenty.deposited,10*63.546/(2*96485.33212));near(twenty.deposited,2*ten.deposited);
 near(twenty.deposited,twenty.anodeLoss);near(twenty.cu,5);near(twenty.charge,10);
 const opened=act(twenty,'wire');near(act(opened,'tick',30).deposited,twenty.deposited);
});
test('inert anode stoichiometry and inventory boundaries',()=>{
 let m=set(init('electrolysis'),'anode','C');m=act(act(act(m,'wire'),'start'),'tick',1e7);
 near(m.cu,0);near(m.oxygen,2.5);near(m.deposited,.005*63.546);assert.equal(m.running,false);
 const zero=set(init('electrolysis'),'current',0);near(act(act(act(zero,'wire'),'start'),'tick',50).charge,0);
});
test('rate separates kinetics from yield and retains lost gas inventory',()=>{
 const connected=act(init('rate'),'connect');
 const slow=act(connected,'start'),fast=act(set(connected,'surface','fine'),'start');
 assert.ok(act(fast,'tick',5).collected>act(slow,'tick',5).collected);
 const end=act(slow,'tick',2000);near(end.extent,2);near(end.collected,act(fast,'tick',2000).collected);
 const leaked=act(act(init('rate'),'start'),'tick',2000);near(leaked.lost,end.collected);near(leaked.collected,0);
 const limiting=act(act(set(connected,'acid',.1),'start'),'tick',1e6);near(limiting.extent,.5);
});
test('heat balances reaction energy and shows physically consistent probe lag',()=>{
 let m=set(init('heat'),'loss',0);m=act(m,'mix');
 near((m.T-25)*(50*4.18+15),25*57.3);near(m.probe,25);
 const later=act(m,'tick',1000);near(later.T,m.T);near(later.probe,m.T);
 const cooling=act(act(init('heat'),'mix'),'tick',1000);assert.ok(cooling.T<later.T&&cooling.T>25);
 const limiting=act(set(init('heat'),'baseVol',10),'mix');near((limiting.T-25)*(35*4.18+15),10*57.3);
});
test('equilibrium obeys stoichiometry, Q=K and equal rates, compression and temperature trends',()=>{
 let m=act(act(init('equilibrium'),'start'),'tick',10000);
 const A=(m.atom-2*m.b)/1000/m.V,B=m.b/1000/m.V;
 near(B/A**2,500,1e-6);near(.06*500*A*A,.06*B);
 const compressed=act(act(m,'compress'),'tick',1000);assert.ok(compressed.b>m.b);
 const warm=act(set(m,'temp',45),'tick',1000);assert.ok(warm.b<m.b);
 const added=act(m,'dose');near(added.atom,m.atom+1);near(added.b,m.b);
});
test('fixed-time dynamics independent of frame partitions',()=>{
 for(const [key,prep] of [['electrolysis','wire'],['rate','connect'],['heat','mix'],['equilibrium','start']]){
  let m=act(act(init(key),prep),'start');const target=act(m,'tick',10);
  for(let i=0;i<100;i++)m=act(m,'tick',.1);
  near(read(target).value,read(m).value,1e-8);
 }
});
test('full receiving flask prevents impossible transfer from a refilled burette',()=>{
 const m=dose(act(dose(init('titration'),10),'refill'),6);
 near(m.delivered+m.aliquot,100);near(m.burette,25);assert.equal(m.lastEvent.type,'capacity');
 assert.deepEqual(set(m,'acid',null).params,m.params);
});
